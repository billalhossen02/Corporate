<section class="banner_section">
    <!-- slider -->
    <div class="banner_slider">

        <?php $__currentLoopData = homePage(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <!-- slider -->
            <div class="slider_inage">
                <img src="<?php echo e(asset('storage/Banner/Banner1/' . $item->branner1)); ?>" alt="">
            </div>

            <div class="slider_inage">
                <img src="<?php echo e(asset('storage/Banner/Banner2/' . $item->branner2)); ?>" alt="">
            </div>

            <div class="slider_inage">
                <img src="<?php echo e(asset('storage/Banner/Banner3/' . $item->branner3)); ?>" alt="">
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
</section>
<?php /**PATH /var/www/html/ngenit/resources/views/frontend/banner.blade.php ENDPATH**/ ?>