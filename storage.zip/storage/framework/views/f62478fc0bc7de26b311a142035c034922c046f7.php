<?php $__env->startSection('content'); ?>
    <!-- /# Sidebar -->
    <?php echo $__env->make('backend.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    <!-- /# Header -->
    <?php echo $__env->make('backend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;


    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
                <!--/# row-->
                <div class="row">
                    <div class="col-lg-8">
                        <div class="card">
                            <div class="card-title">
                                <h4>Solution Page </h4>

                            </div>
                            <div class="card-body">
                                <a href="<?php echo e(route('create_solution')); ?>"><button style="float: right"
                                        class="btn btn-info">Create a Solution</button> </a>
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Title</th>
                                                
                                                <th style="width: 140px">Action</th>
                                                
                                            </tr>
                                        </thead>
                                        <tbody>
                                            
                                            <?php $__currentLoopData = $solutions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $solution): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($solution->id); ?></td>
                                                    <td><?php echo e($solution->title); ?></td>
                                                    <td>
                                                        <a href="<?php echo e(url('solutions/' . $solution->id)); ?>">
                                                            <button class="btn-sm btn-warning">Edit</button>
                                                        </a>
                                                        <a href="<?php echo e(url('delete/solutions/' . $solution->id)); ?>">
                                                            <button class="btn-sm btn-danger">Delete</button>
                                                        </a>

                                                        </form>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/ngenit/resources/views/backend/solutions/view.blade.php ENDPATH**/ ?>