<?php $__env->startSection('content'); ?>

<?php echo $__env->make('frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

 <!--======Featured client stories==========-->
 <section class="header_title_clinet_stories">
    <h1>Client stories</h1>
</section>

<section class="container">
    <div class="featured_client_stories_wrapper">
        <div class="featured_client_stories">
            <div class="container">
                <div class="featured_client_stories_title">
                    <h1 class="">Related posts</h1>
                </div>
    
                <div class="row">
                    
                    <div class="col-lg-3 col-md-6 col-sm-12">
                        <div class="client_stories_item">
                            <a href="#">
                                <img class="img-fluid" src="<?php echo e(asset('assets/frontend/image/single-blog/item/item (1).jpg')); ?>" alt="">
                                <h4>Tech journal</h6>
                                <h3>Dan Groves, VP of IT for Westerra Credit Union - Disruption is Part of the Journey</h3>
                            </a>
                            
                        </div> 
                    </div>
                    
                    <div class="col-lg-3 col-md-6 col-sm-12">
                        <div class="client_stories_item">
                            <a href="">
                                <img class="img-fluid" src="<?php echo e(asset('assets/frontend/image/single-blog/item/item (2).jpg')); ?>" alt="">
                                <h4>Video</h6>
                                <h3>EcoStruxure IT Mainfreight Case Study</h3>
                            </a>
                            
                        </div> 
                    </div>
                    
                    <div class="col-lg-3 col-md-6 col-sm-12">
                        <div class="client_stories_item">
                            <a href="">
                                <img class="img-fluid" src="<?php echo e(asset('assets/frontend/image/single-blog/item/item (3).jpg')); ?>" alt="">
                                <h4>Tech journal</h6>
                                <h3>Acer and Google Chrome OS Partner for Sustainable Solutions</h3>
                            </a>
                            
                        </div> 
                    </div>
                    
                    <div class="col-lg-3 col-md-6 col-sm-12">
                        <div class="client_stories_item">
                            <a href="">
                                <img class="img-fluid" src="<?php echo e(asset('assets/frontend/image/single-blog/item/item (4).jpg')); ?>" alt="">
                                <h4>Free ebook</h6>
                                <h3>Discover the True Potential of Virtualization</h3>
                            </a>
                            
                        </div> 
                    </div>
                </div>
    
            </div>
        </div>
    </div>
    
</section>
<!----------Featured client stories End--------->
<br><br>
<hr>
<br><br>

<?php echo e(Form::open(['method' => 'GET', 'enctype' => 'multipart/form-data'])); ?>


<!--============Content & Filter=============-->
<section class="container">
    <!----------Filter Top-nav Bar --------->
    <div class="clinet_stories_filter_top_bar">
        <label>Results per page </label>
        <?php echo e(Form::select('per_page', array_combine([5,10,20,40], [5,10,20,40]), $request->per_page, ['class' => 'autoSubmit'])); ?>

    </div>
    <hr>
    <div class="row">
        <!----------Sidebar client stories --------->
        <div class="col-lg-3 col-md-3 col-sm-12">
            <div class="sidebar_client_stories">
                <label> <b><?php echo e($blogs->count()); ?> </b>results matched your search</label>

                <hr>
                <!--------Your search--------->
                <div class="client_stories_your_search">
                    <h6 class="mb-4">Your search</h6>

                    <?php if($request->keyword): ?>
                        <div class="alert alert-secondary alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert">&times;</button><?php echo e($request->keyword); ?>

                        </div>
                        <?php endif; ?>

                        <?php if($request->filterindustry): ?>
                        <?php $__currentLoopData = $request->filterindustry; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="alert alert-secondary alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert">&times;</button><?php echo e($item); ?>

                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                    <?php if($request->filtersolution): ?>
                    <?php $__currentLoopData = $request->filtersolution; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="alert alert-secondary alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert">&times;</button><?php echo e($item); ?>

                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

                </div>
                
                <hr>
                <form action="<?php echo e(URL::current()); ?>" method="GET">
                <!-------Content Results---------->
                <div class="client_stories_narrow_content">
                    <h6 class="mb-4">Narrow content results</h6>
                    <input type="text" name="keyword" placeholder="BY KEYWORD...">
                </div>

                <br>
                    <!-------Apply Filters Button---------->
                    <div id="sticker">
                        <div class="product_apply_filter_btn d-flex">
                        <button onclick="show()" type="submit">Apply Filters</button>
                    </div>
                    </div>

                <hr>
                <!--------Topic--------->
                <div class="client_stories_filter_category">
                    <h6 onclick="myFunction()" class="mb-4"><i class="fa-solid fa-caret-down"></i> Industry</h6>
                    
                    <div id="filter_category">
                        <?php $__currentLoopData = $industries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $checked = [];
                            if(isset($_GET['filterindustry']))
                            {
                                $checked = $_GET['filterindustry'];
                            }
                        ?>
                        <div class="form-check p-0 m-0">
                            <input type="checkbox" name="filterindustry[]" class="custom" value="<?php echo e($item->title); ?>"
                            <?php if(in_array($item->title,$checked)): ?> checked <?php endif; ?>
                            />
                            <?php echo e($item->title); ?> <br>
                            </div>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    
                </div>
                <hr>
                <!--------Industry--------->
                <div class="client_stories_filter_category">
                    <h6 onclick="showhide()" class="mb-4"><i class="fa-solid fa-caret-down"></i> Solution</h6>
                    
                    <div id="newpost">
                        <?php $__currentLoopData = $solutions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $checked = [];
                            if(isset($_GET['filtersolution']))
                            {
                                $checked = $_GET['filtersolution'];
                            }
                        ?>
                        <div class="form-check p-0 m-0">
                            <input type="checkbox" name="filtersolution[]" class="custom" value="<?php echo e($item->title); ?>"
                            <?php if(in_array($item->title,$checked)): ?> checked <?php endif; ?>
                            />
                            <?php echo e($item->title); ?> <br>
                            </div>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    
                </div>
                <hr>
                <!--------End--------->

            </div>
        </div>
        <!----------conternt client stories --------->
        <div class="col-lg-9 col-md-9 col-sm-12">
            <div class="row" style="justify-content: center">
                
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="client_stories_content_item">
           
                        <?php
                        $tags = explode(',', $blog->tags);
                        ?>
                        <ul style="display: flex;
                                   flex-direction: row;
                                   flex-wrap: wrap;">
                            <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="px-1">
                              <p style="color:rgb(172, 27, 124)"><?php echo e($tag); ?></p>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </ul>
                        <a href="<?php echo e(url('/blogs/'.$blog['id'])); ?>">
                            <img class="img-fluid" src="<?php echo e($blog->logo ? asset ('storage/Blog/' . $blog->logo) : asset('assets/frontend/image/Logo/logo.png')); ?>" alt="">
                            
                            
                            <h3 class="mt-4"><?php echo $blog->title; ?> </h3>
                            <p><?php echo $blog->header1; ?></p>
                            <h4>Client Story / <?php echo e($blog->created_at); ?></h4>
                        </a>
                    </div> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                
                
            </div>
        </div>
    </div>
    <?php echo e(Form::close()); ?>


    <!------------------Pagination------------------->
    
</section>
<hr>
<br>
<!----------End Page--------->

<script>
    function myFunction() {
        var x = document.getElementById("filter_category");
        if (x.style.display === "none") {
            x.style.display = "block";
        } else {
            x.style.display = "none";
        }
    }  
    function showhide()
    {  
         var div = document.getElementById("newpost");  
         if (div.style.display !== "none") 
         {  
             div.style.display = "none";  
         }  
         else
         {  
             div.style.display = "block";  
         }  
    } 
    //-----------------
    // $(document).ready(function() {
    //     var s = $("#sticker");
    //     var pos = s.position();					   
    //     $(window).scroll(function() {
    //         var windowpos = $(window).scrollTop();
    //         if (windowpos >= pos.top) {
    //             s.addClass("stick");
    //         } else {
    //             s.removeClass("stick");	
    //         }
    //     });
    // });
    //-----------------
    function ReadMoreLess() {
        var dots = document.getElementById("dots");
        var moreText = document.getElementById("more");
        var iMoreLess = document.getElementById("iMoreLess");
        var lblText = document.getElementById("lblText");
        if (dots.style.display === "none") {
            dots.style.display = "inline";
            iMoreLess.className = "fa fa-chevron-circle-right";
            lblText.innerHTML = "See all open positions";
            moreText.style.display = "none";
        } else {
            dots.style.display = "none";
            iMoreLess.className = "fa fa-chevron-circle-down";
            lblText.innerHTML = "Hide all open positions";
            moreText.style.display = "inline";
        }
    }
</script>
<script>
    $(".autoSubmit").change(function() {
      $(this).parents("form").submit()
    });

    function show(){
        $("#count").show();
        $("#yoursearch").show();
        $("#hr").show();
    }
  </script>

<?php echo $__env->make('frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/ngenit/resources/views/frontend/blogs/blogs.blade.php ENDPATH**/ ?>