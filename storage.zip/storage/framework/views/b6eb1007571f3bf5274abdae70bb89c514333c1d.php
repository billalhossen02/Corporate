
<!-- jquery vendor -->
   <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
   <script src="<?php echo e(asset('assets/backend/js/lib/jquery.min.js')); ?>"></script>
   <script src="<?php echo e(asset('assets/backend/js/lib/jquery.nanoscroller.min.js')); ?>"></script>
   <!-- nano scroller -->
   <script src="<?php echo e(asset('assets/backend/js/lib/menubar/sidebar.js')); ?>"></script>
   <script src="<?php echo e(asset('assets/backend/js/lib/preloader/pace.min.js')); ?>"></script>
   <!-- bootstrap -->
   <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>
   <script src="<?php echo e(asset('assets/backend/js/lib/bootstrap.min.js')); ?>"></script>
   <script src="<?php echo e(asset('assets/backend/js/scripts.js')); ?>"></script>

<?php /**PATH /var/www/html/ngenit/resources/views/backend/style/js.blade.php ENDPATH**/ ?>