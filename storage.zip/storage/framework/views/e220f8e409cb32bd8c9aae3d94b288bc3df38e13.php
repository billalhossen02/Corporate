<?php $__env->startSection('content'); ?>

      <!-- /# Sidebar -->
   <?php echo $__env->make('backend.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
   <!-- /# Header -->
   <?php echo $__env->make('backend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

   <div class="content-wrap">
    <div class="main">
        <div class="container-fluid">
           
                <!-- /# row -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-title">
                                <h4>Create Catagory</h4>
                            </div>
                            <div class="card-body">
                                <div class="basic-form">
                                    <form class="row" action="<?php echo e(route('addCategory')); ?>" method="POST" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>

                                        <div class="form-group col-lg-6 col-md-6 col-sm-12">
                                            <label>Category</label>
                                            <select name="category" class="form-control">
                                                <option>Select Type</option>
                                                <?php $__currentLoopData = productType(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item); ?>"><?php echo e($item); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>

                                        <div class="form-group col-lg-6 col-md-6 col-sm-12">
                                            <label>Sub Category</label>
                                            <input type="text" name="sub_category" class="form-control" placeholder="Enter value...">
                                        </div>
                                        <div class="form-group col-lg-6 col-md-6 col-sm-12">
                                            <label>Sub Image</label>
                                            <input type="file" name="sub_image" class="form-control" placeholder="Upload your image">
                                        </div>

                                        <div class="form-group col-lg-6 col-md-6 col-sm-12">
                                            <label>Sub Sub Category</label>
                                            <input type="text" name="sub_sub_category" class="form-control" placeholder="Enter value...">
                                        </div>
                                        <div class="form-group col-lg-6 col-md-6 col-sm-12">
                                            <label>Sub Sub Image</label>
                                            <input type="file" name="sub_sub_image" class="form-control" placeholder="Upload your image">
                                        </div>

                                        <div class="form-group col-lg-6 col-md-6 col-sm-12">
                                            <label>Sub Sub Sub Category</label>
                                            <input type="text" name="sub_sub_sub_category" class="form-control" placeholder="Enter value...">
                                        </div>
                                        <div class="form-group col-lg-6 col-md-6 col-sm-12">
                                            <label>Sub Sub Sub Image</label>
                                            <input type="file" name="sub_sub_sub_image" class="form-control" placeholder="Upload your image">
                                        </div>
                                    </div>

                                        <button type="submit" class="btn btn-info ml-3">Add Category</button>
                                    </form>
                            </div>
                        </div>
                    </div>
                </div>
                
        </div>
    </div>
   </div>
   
<?php $__env->stopSection(); ?>

 
<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/ngenit/resources/views/backend/category/category_create.blade.php ENDPATH**/ ?>