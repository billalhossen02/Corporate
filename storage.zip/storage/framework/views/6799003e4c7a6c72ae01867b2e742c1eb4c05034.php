<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <title>NGenIt Corporate</title>
    <link rel="icon" href="<?php echo e(asset('assets/frontend/image/Logo/logo.png')); ?>">
    <?php echo $__env->make('frontend.style.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body class="p-0 m-0">

    <div style="margin-top:130px">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <script src="<?php echo e(asset('assets/frontend/js/main.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/frontend/js/javascript.mr.js')); ?>"></script>

    <?php echo $__env->make('frontend.style.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div>
        <?php echo $__env->make('frontend.client.feedback', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <?php echo e(\TawkTo::widgetCode()); ?>


</body>

</html>
<?php /**PATH /var/www/html/ngenit/resources/views/frontend/master.blade.php ENDPATH**/ ?>