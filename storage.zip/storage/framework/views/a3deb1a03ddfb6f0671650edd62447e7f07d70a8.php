<?php $__env->startSection('content'); ?>

      <!-- /# Sidebar -->
   <?php echo $__env->make('backend.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
   <!-- /# Header -->
   <?php echo $__env->make('backend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

   <div class="content-wrap">
    <div class="main">
        <div class="container-fluid">
           
                <!-- /# row -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-title">
                                <h4>Edit Product</h4>
                            </div>
                            <div class="card-body">
                                <div class="basic-form">
                                    <form class="row" action="<?php echo e(url('update/product/'.$data->id)); ?>" method="POST" enctype="multipart/form-data">
                                       <?php echo csrf_field(); ?>
                                        <div class="form-group col-lg-4 col-md-6 col-sm-12">
                                            <label>Name</label>
                                            <input type="name" name="title" class="form-control" value="<?php echo e($data->title); ?>">
                                        </div>
                                        <div class="form-group col-lg-4 col-md-6 col-sm-12">
                                            <label>Price</label>
                                            <input type="number" name="price" class="form-control" value="<?php echo e($data->price); ?>">
                                        </div>
                                        <div class="form-group col-lg-4 col-md-6 col-sm-12">
                                            <label>Description</label>
                                            <textarea class="form-control" name="description" rows="5" value="<?php echo e($data->description); ?>" placeholder="<?php echo e($data->description); ?>"></textarea>
                                        </div>
                                      
                                        <div class="form-group col-lg-4 col-md-6 col-sm-12">
                                            <label>Category</label>
                                            <select name="category" class="form-control">
                                                <option><?php echo e($data->category); ?></option>
                                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->title); ?>"><?php echo e($item->title); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        
                                        <div class="form-group col-lg-4 col-md-6 col-sm-12">
                                            <label>Brands</label>
                                            <select name="brand" class="form-control">
                                                <option><?php echo e($data->brand); ?></option>
                                                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->title); ?>"><?php echo e($item->title); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>

                                        <div class="form-group col-lg-4 col-md-6 col-sm-12">
                                            <label>Industries</label>
                                            <select name="industry" class="form-control">
                                                <option><?php echo e($data->industry); ?></option>
                                                <?php $__currentLoopData = $industries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->title); ?>"><?php echo e($item->title); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>

                                        <div class="form-group col-lg-4 col-md-6 col-sm-12">
                                            <img src="<?php echo e(asset('storage/Product/'.$data->image)); ?>" width="400px" alt="">
                                            <input type="file" name="image" class="form-control" required>
                                        </div>
                                     </div>
                                    <button type="submit" class="btn btn-info ml-2">Update Product</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                
        </div>
    </div>
</div>
   
<?php $__env->stopSection(); ?>

    
    


<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/ngenit/resources/views/backend/products/product_edit.blade.php ENDPATH**/ ?>