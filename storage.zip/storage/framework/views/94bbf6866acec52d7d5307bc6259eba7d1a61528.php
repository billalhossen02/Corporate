<?php $__env->startSection('content'); ?>
    <!-- /# Sidebar -->
    <?php echo $__env->make('backend.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    <!-- /# Header -->
    <?php echo $__env->make('backend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
                <!--/# row-->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-title">
                                <h4>Home Page <span><a href="<?php echo e(url('choose')); ?>"><button
                                                class="btn btn-sm btn-info" style="font-size: 12px; float:right">Create a New
                                                Page</button></a>
                                    </span></h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Page Name</th>
                                                <th class="text-right">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php ($i = 1); ?>
                                            <?php $__currentLoopData = $home->take(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($i++); ?></td>
                                                    <td>Home Page</td>

                                                    <td class="pull-right">
                                                        <a href="<?php echo e(url('/')); ?>"><button
                                                                class="btn btn-sm btn-outline-primary"><i class="fa fa-eye"
                                                                    aria-hidden="true"></i>
                                                            </button></a>

                                                        <a href="<?php echo e(url('pagebuilder/home/'.$item->id)); ?>"><button class="btn btn-sm  btn-outline-danger"><i class="fa fa-trash" aria-hidden="true"></i></button></a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            <div class="card-title pt-3">
                                <h4>All Brand Page</h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Brand</th>
                                                <th class="text-right">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php ($i = 1); ?>
                                            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($i++); ?></td>
                                                    <td><?php echo e($item->brand); ?></td>

                                                    <td class="pull-right">
                                                        <a href="<?php echo e(url('hardware/' . $item->brand)); ?>"><button
                                                                class="btn btn-sm btn-outline-primary"><i class="fa fa-eye"
                                                                    aria-hidden="true"></i>
                                                            </button></a>

                                                            <a href="<?php echo e(url('pagebuilder/brand/delete/' . $item->id)); ?>"><button
                                                                class="btn btn-sm  btn-outline-danger"><i
                                                                    class="fa fa-trash" aria-hidden="true"></i></button></a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>


                            <div class="card-title pt-3">
                                <h4>All Category Page</h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Category</th>
                                                <th class="text-right">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php ($i = 1); ?>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($i++); ?></td>
                                                    <td><?php echo e($item->category); ?></td>

                                                    <td class="pull-right">
                                                        <a href="<?php echo e(url('category.html/' . $item->category)); ?>"><button
                                                                class="btn btn-sm btn-outline-primary"><i class="fa fa-eye"
                                                                    aria-hidden="true"></i>
                                                            </button></a>
                                                        <a href="<?php echo e(url('pagebuilder/category/delete/' . $item->id)); ?>"><button
                                                                class="btn btn-sm  btn-outline-danger"><i
                                                                    class="fa fa-trash" aria-hidden="true"></i></button></a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <style>
        tr {
            border-bottom: 1px solid #E7E7E7;
        }

        td {
            border: none;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/ngenit/resources/views/backend/pagebuilder/view.blade.php ENDPATH**/ ?>