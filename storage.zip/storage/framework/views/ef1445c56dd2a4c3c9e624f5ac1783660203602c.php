<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!--========Header Title==========-->
    <section class="header_title_product_filter"
        style="background-image:url('<?php echo e(asset('assets/frontend/image/desktop-shop-hero.jpg')); ?>');
    ">
        <h1>Desktop</h1>
    </section>
    <!----------Header Title End--------->
    <br><br>
    <?php echo e(Form::open(['method' => 'GET', 'enctype' => 'multipart/form-data'])); ?>

    <!--============Content & Filter=============-->
    <section class="container">
        <!----------Filter Top-nav Bar --------->
        <div class="clinet_stories_filter_top_bar">
            <label for="Per Page">Results Per Page</label>
            <?php echo e(Form::select('per_page', array_combine([5, 10, 20, 40], [5, 10, 20, 40]), $request->per_page, ['class' => 'autoSubmit'])); ?>


            <span class="product_go_to_next_pge"><a href="<?php echo e($products->nextPageUrl()); ?>" class="pull-right">Go to next
                    page...<i class="fa-solid fa-chevron-right"></i></a></span>
        </div>
        <hr>
        <div class="row">
            <!----------Sidebar client stories --------->
            <div class="col-lg-3 col-sm-12">
                <div class="sidebar_client_stories">
                    <label id="count"><b><?php echo e($products->count()); ?></b> results matched your search</label>
                    <hr id="hr">
                    <!--------Your search--------->
                    <div id="yoursearch" class="client_stories_your_search">
                        <h6 class="mb-4">Your search</h6>

                        <?php if($request->keyword): ?>
                            <div class="alert alert-secondary alert-dismissible">
                                <button type="button" class="close"
                                    data-dismiss="alert">&times;</button><?php echo e($request->keyword); ?>

                            </div>
                        <?php endif; ?>

                        <?php if($request->filterbrand): ?>
                            <?php $__currentLoopData = $request->filterbrand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="alert alert-secondary alert-dismissible">
                                    <button type="button" class="close"
                                        data-dismiss="alert">&times;</button><?php echo e($item); ?>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                        <?php if($request->filtercategory): ?>
                            <?php $__currentLoopData = $request->filtercategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="alert alert-secondary alert-dismissible">
                                    <button type="button" class="close"
                                        data-dismiss="alert">&times;</button><?php echo e($item); ?>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                    </div>
                    <hr id="hr">
                    <form action="<?php echo e(URL::current()); ?>" method="GET">

                        <!-------Content Results---------->
                        <div class="client_stories_narrow_content">
                            <h6 class="mb-4">Narrow results</h6>
                            <input type="text" name="keyword" placeholder="BY KEYWORD...">
                        </div>
                        <hr>


                        <!-------Apply Filters Button---------->
                        <div id="sticker">
                            <div class="product_apply_filter_btn d-flex">
                                <button onclick="show()" type="submit">Apply Filters</button>
                            </div>
                        </div>

                        <hr>

                        <!-------List Price---------->
                        <div class="product_list_price">
                            <h6 class="mb-4">List Price</h6>
                            <form action="#">
                                <input type="number" id="quantity" name="low" style="width: 80px;">
                                <label for="#">to</label>
                                <input type="number" id="quantity" name="high" style="width: 80px;">
                            </form>
                        </div>
                        <hr>

                        <!-------Stock Status---------->
                        <div class="product_stock_status">
                            <h6 class="mb-4">Stock Status</h6>
                            <div class="form-check">
                                <input class="form-check-input custom" type="checkbox" id="flexCheckDefault">
                                <span class="ml-2">Show only in-stock items</span>
                            </div>

                        </div>
                        <hr>

                        <!--------Manufacturers--------->
                        <div class="client_stories_filter_category">
                            <h6 onclick="myFunction()" class="mb-4"><i class="fa-solid fa-caret-down"></i> Brands
                            </h6>
                        </div>

                        <div id="filter_category">
                            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $checked = [];
                                    if (isset($_GET['filterbrand'])) {
                                        $checked = $_GET['filterbrand'];
                                    }
                                ?>
                                <div class="form-check p-0 m-0">
                                    <input type="checkbox" name="filterbrand[]" class="custom" value="<?php echo e($item->title); ?>"
                                        <?php if(in_array($item->title, $checked)): ?> checked <?php endif; ?> />
                                    <?php echo e($item->title); ?> <br>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </div>

                        <hr>

                        <!--------System / Type--------->
                        <div class="client_stories_filter_category">
                            <h6 onclick="showhide()" class="mb-4"><i class="fa-solid fa-caret-down"></i> Category</h6>
                            <div id="newpost">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $checked = [];
                                        if (isset($_GET['filtercategory'])) {
                                            $checked = $_GET['filtercategory'];
                                        }
                                    ?>
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input custom" name="filtercategory[]"
                                            value="<?php echo e($item->category); ?>"
                                            <?php if(in_array($item->sub_category, $checked)): ?> checked <?php endif; ?> />
                                        <?php echo e($item->sub_category); ?>

                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </div>
                    </form>
                </div>
                <hr>

                <!--------End--------->

            </div>
        </div>
        <!----------conternt client stories --------->
        <div class="col-lg-9 col-sm-12">


            <!--------item------->
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="product_content_item row">
                    <div class="col-lg-3 col-md-4 col-sm-12">
                        <img class="img-fluid" src="<?php echo e(asset('storage/Product/' . $item->image)); ?>" alt="">
                    </div>

                    <div class="col-lg-9 col-md-8 col-sm-12 product_content_item">
                        <a href="#">
                            <h3>
                                <a href="<?php echo e(route('product', ['id' => $item->id])); ?>"
                                    class="product_item_content_name"><?php echo e($item->title); ?></a>
                            </h3>
                        </a>
                        <!--Add To Basket-->
                        <div class="row">
                            <div class="col-lg-7 col-sm-12">
                                
                                <ul class="mt-2">
                                    <li><?php echo e($item->description); ?></li>
                                </ul>
                            </div>
                            <div class="col-lg-5 col-sm-12">
                                <h4>List Price</h4>
                                <h3>USD $<?php echo e($item->price); ?></h3>
                                <h6>1,380 in stock</h6>
                                <!------------>
                                <form action="<?php echo e(route('cart.store')); ?>" method="POST" enctype="multipart/form-data">
                                    <input type="hidden" value="<?php echo e($item->id); ?>" name="id">
                                    <input type="hidden" value="<?php echo e($item->title); ?>" name="name">
                                    <input type="hidden" value="<?php echo e($item->price); ?>" name="price">
                                    <input type="hidden" value="<?php echo e($item->image); ?>" name="image">
                                    <div class="row mt-4">
                                        <div class="col-4 quantity">
                                            <input type="number" min="1" name="quantity" max="9"
                                                step="1" value="1">
                                        </div>
                                        <div class="col-8 filter_btn">
                                            <button onclick="a()"
                                                style="background:transparent;border:none;color:white">Add To
                                                Basket</button>
                                        </div>
                                    </div>
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </div>
                    </div>
                </div><br>
                <hr><br><br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        </div>
        </div>

        <?php echo e(Form::close()); ?>


        <!------------------Pagination------------------->
        <div class="d-flex justify-content-center">
            <nav aria-label="Page navigation example">
                <?php echo $products->withQueryString()->links(); ?>

            </nav>
        </div>
    </section>
    <br>

    <style>
        .page-item.active .page-link {
            z-index: 1;
            color: #fff;
            background-color: #ae0a46 !important;
            border-color: #ae0a46 !important;
        }
    </style>




    <!---================================================================--->

    <script>
        // $("#count").hide();
        // $("#yoursearch").hide();
        // $("#hr").hide();

        function myFunction() {
            var x = document.getElementById("filter_category");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
        }

        function showhide() {
            var div = document.getElementById("newpost");
            if (div.style.display !== "none") {
                div.style.display = "none";
            } else {
                div.style.display = "block";
            }
        }
        //-----------------
        // $(document).ready(function() {
        // 	var s = $("#sticker");
        // 	var pos = s.position();
        // 	$(window).scroll(function() {
        // 		var windowpos = $(window).scrollTop();
        // 		if (windowpos > pos.top) {
        // 			s.addClass("stick");
        // 		} else {
        // 			s.removeClass("stick");
        // 		}
        // 	});
        // });
        //-----------------
        function ReadMoreLess() {
            var dots = document.getElementById("dots");
            var moreText = document.getElementById("more");
            var iMoreLess = document.getElementById("iMoreLess");
            var lblText = document.getElementById("lblText");
            if (dots.style.display === "none") {
                dots.style.display = "inline";
                iMoreLess.className = "fa fa-chevron-circle-right";
                lblText.innerHTML = "See all open positions";
                moreText.style.display = "none";
            } else {
                dots.style.display = "none";
                iMoreLess.className = "fa fa-chevron-circle-down";
                lblText.innerHTML = "Hide all open positions";
                moreText.style.display = "inline";
            }
        }
    </script>

    <script>
        $(".autoSubmit").change(function() {
            $(this).parents("form").submit()
        });

        function show() {
            $("#count").show();
            $("#yoursearch").show();
            $("#hr").show();
        }
    </script>

    <?php echo $__env->make('frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/ngenit/resources/views/frontend/product/filert.blade.php ENDPATH**/ ?>