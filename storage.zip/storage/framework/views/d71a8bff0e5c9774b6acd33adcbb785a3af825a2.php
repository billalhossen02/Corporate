<link rel="shortcut icon" href="http://placehold.it/64.png/000/fff">

<!-- Styles -->

<link href="<?php echo e(asset('assets/backend/css/lib/sidebar.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/backend/css/lib/bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/bootswatch.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/backend/css/style.css')); ?>" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css">
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet" />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/lykmapipo/themify-icons@0.1.2/css/themify-icons.css">

<style>
    body::-webkit-scrollbar {
        width: 10px;
    }

    body::-webkit-scrollbar-track {
        background: #fff;
    }

    body::-webkit-scrollbar-thumb {
        background-color: #000;
        border-radius: 10px;
    }
</style>
<?php /**PATH /var/www/html/ngenit/resources/views/backend/style/css.blade.php ENDPATH**/ ?>