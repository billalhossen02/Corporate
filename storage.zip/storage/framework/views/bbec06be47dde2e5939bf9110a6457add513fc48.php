<?php $__env->startSection('content'); ?>
    <!-- /# Sidebar -->
    <?php echo $__env->make('backend.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    <!-- /# Header -->
    <?php echo $__env->make('backend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
                <!--/# row-->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-title">
                                <h4>Industry Page </h4>

                            </div>
                            <div class="card-body">
                                <a href="<?php echo e(route('IndustryT')); ?>"><button style="float: right" class="btn btn-info">Create
                                        an Industry</button> </a>
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Name</th>
                                                <th>Header</th>
                                                <th>Image</th>
                                                <th style="width:125px; ">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php ($i = 1); ?>
                                            <?php $__currentLoopData = $industries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($i++); ?></td>
                                                    <td><?php echo e($item->title); ?></td>
                                                    <td><?php echo e($item->header); ?></td>
                                                    <td><img src="<?php echo e(asset('storage/Industry/' . $item->image)); ?>"
                                                            width="20px" alt=""></td>
                                                    <td>
                                                        <a href="<?php echo e(url('edit/industry/' . $item->id)); ?>"><button
                                                                class="btn-sm btn-warning"><i
                                                                    class="fa-solid fa-pen-to-square"></i></button></a>
                                                        <a href="<?php echo e(url('delete/industry/' . $item->id)); ?>"><button
                                                                class="btn-sm btn-danger"><i
                                                                    class="fa-solid fa-trash"></i></button></a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/ngenit/resources/views/backend/industry/industry_view.blade.php ENDPATH**/ ?>