<?php $__env->startSection('content'); ?>
    <!-- /# Sidebar -->
    <?php echo $__env->make('backend.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    <!-- /# Header -->
    <?php echo $__env->make('backend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
                <!--/# row-->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-title">
                                <h4>Product Page </h4>

                            </div>
                            <div class="card-body">
                                <a href="<?php echo e(route('ProductT')); ?>"><button style="float:right"
                                        class="btn btn-sm btn-info">Create a
                                        Product</button> </a>
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Name</th>
                                                <th>Image</th>
                                                <th>Description</th>
                                                <th>Price</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php ($i = 1); ?>
                                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($i++); ?></td>
                                                    <td><?php echo e($item->title); ?></td>
                                                    <td><img src="<?php echo e(asset('storage/Product/' . $item->image)); ?>"
                                                            width="70px" alt=""></td>
                                                    <td><?php echo e($item->description); ?></td>
                                                    <td><?php echo e($item->price); ?></td>
                                                    <td style="width: 100px;>                                            ">
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product-edit')): ?>
                                                            <a style="padding-inline: 3px;"
                                                                href="<?php echo e(url('edit/product/' . $item->id)); ?>"><button
                                                                    class="btn btn-sm btn-warning"><i
                                                                        class="fa-solid fa-pen-to-square"></i></button></a>
                                                        <?php endif; ?>
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product-delete')): ?>
                                                            <a style="padding-inline: 3px;"
                                                                href="<?php echo e(url('delete/product/' . $item->id)); ?>"><button
                                                                    class="btn btn-sm btn-danger"><i
                                                                        class="fa-solid fa-trash"></i></button></a>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>

                                    </table>
                                    <?php echo e($products->links()); ?>


                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/ngenit/resources/views/backend/products/product_view.blade.php ENDPATH**/ ?>