<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!--========Header Title==========-->
    <section class="common_product_header"
        style="background-image:url('<?php echo e(asset('assets/frontend/image/buy-category-hero.jpg')); ?>')">
        <div class="container">
            <h1>Ready to shop?</h1>
            <h3>Explore our product categories to see options for hardware, software and accessories. Use our configurators
                for advanced help with your selection. And, find discounts under our tech deals.</h3>

            <div class="row d-flex justify-content-center">
                <div class="col-lg-2"></div>
                <!--BUTTON START-->
                <div class="col-lg-3 col-sm-12 d-flex justify-content-center mb-4">
                    <a class="search_all_product_btn" href="<?php echo e(route('filter')); ?>">Search all Products</a>
                </div>
                <div class="col-lg-3 col-sm-12 d-flex justify-content-center mb-4">
                    <a class="create_your_account_btn " href="<?php echo e(route('register')); ?>">Create your account</a>
                </div>
                <!--BUTTON END-->
                <div class="col-lg-2"></div>
                </span>

            </div>
        </div>

    </section>
    <!----------Header Title End--------->


    <!--=======Popular products Begin=======-->
    <section class="container">
        <div class="popular_product_section_content">
            <!-- section title -->
            <div class="common_product_item_title">
                <h3>Top Products</h3>
            </div>
            <!-- wrapper -->
            <div class="populer_product_slider">

                <!-- product_item -->
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="product_item">
                        <!-- image -->
                        <div class="product_item_thumbnail">
                            <img src="<?php echo e(asset('storage/Product/' . $item->image)); ?>" alt="">
                        </div>

                        <!-- product content -->
                        <div class="product_item_content">
                            <a href="<?php echo e(route('product', ['id' => $item->id])); ?>"
                                class="product_item_content_name"><?php echo e($item->title); ?></a>

                            <!-- price -->
                            <div class="product_item_price">
                                <span class="price_currency">usd</span>
                                <span class="price_currency_value">$<?php echo e($item->price); ?></span>
                            </div>

                            <form class="myForm">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" value="<?php echo e($item->id); ?>" name="id" id="id">
                                <input type="hidden" value="<?php echo e($item->title); ?>" name="name" id="name">
                                <input type="hidden" value="<?php echo e($item->price); ?>" name="price" id="price">
                                <input type="hidden" value="<?php echo e($item->image); ?>" name="image" id="image">
                                <input type="hidden" value="1" name="quantity" id="quantity">
                                <button type="submit" class="product_button product_button_change" data-toggle="modal"
                                    id="addToBasket" data-target="#mediumModal"
                                    data-attr="<?php echo e(route('modal', ['id' => $item->id])); ?>">Add to Basket</button>
                            </form>
                            <!-- button -->
                        </div>

                    </div>
                    <!-- product item -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section><br>
    <!-- Related Product Section End -->

    <!--========Shop by category=======-->
    <section class="container">
        <!--Title-->
        <div class="common_product_item_title">
            <h3>Shop By Category</h3>

        </div>
        <!--Product Category-->
        <div class="row">
            <!--Category item-->
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xl-2 col-lg-2 col-md-3 col-sm-6 p-4">
                    <img class="img-fluid mb-4" src="<?php echo e(asset('storage/Category/' . $item->sub_img)); ?>" alt="">
                    <div class="common_product_item_text">
                        <a href="<?php echo e(url('category.html/' . $item->sub_category)); ?>"><?php echo e($item->sub_category); ?></a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </section>
    <!------Shop by category---->

    <!--=====Transform your devices======-->
    <section class="container">
        <div class="transform_devices_wrapper">
            <div class="row" style="border: 1px solid #e3e3e3;">
                <div class="col-lg-6 col-md-6 col-sm-12 p-0">
                    <img class="img-fluid" src="<?php echo e(asset('assets/frontend/image/windows-11-with-cad-drawer.jpg')); ?>"
                        alt="">
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 transform_devices_blog">
                    <img src="images/windows-11.png" alt="">
                    <h2>Transform your devices</h2>
                    <p>with intuitive designs and advanced features available through Windows® 11 Pro.</p>
                    <a href="<?php echo e(url('blogs')); ?>">Learn more</a>
                </div>
            </div>
        </div>
    </section>
    <!-----Transform your devices----->

    <!--=====Need Help Finding Prodcut======-->
    <section class="need_help_finding_prodcut"
        style="background-image:url('<?php echo e(asset('assets/frontend/image/help-background-imges.jpg')); ?>')">
        <div class="container">
            <h2>Need help finding the right product?</h2>
            <h3>Our product selectors and configurators will pinpoint the right item for your organization. These
                easy-to-use Insight Intelligent Technology™ tools let you choose your needs and requirements, and then
                generate the results that are the best match.</h3>
            <div class="d-flex justify-content-center">
                <a href="#" class="finding_product_btn">Explore our configurators</a>
            </div>

        </div>
    </section>
    <!------Need Help Finding End---->

    <!--===== Technolgy Deals======-->
    <section class="common_product_technolgy_deals_wrapper">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12">
                    <img class="img-fluid" src="<?php echo e(asset('assets/frontend/image/technology-deals.png')); ?>" alt="">
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 technolgy_deals_blog">
                    <h2>Unbeatable technology deals</h2>
                    <p>Explore <a href="#">discounts,</a> <a href="#">refurbished products</a> and limited-time
                        offers. From laptops to cables, accessories and printers, we offer the technology you need at
                        affordable prices — you gain the option of discounted pricing from a variety of brands.</p><br>
                    <a href="<?php echo e(url('techdeal.html')); ?>" class="common_button">Shop & Save</a>
                </div>
            </div>
        </div>
    </section>

    <!----Technolgy Deals End---->

    <!--========Shop by category=======-->
    <section class="container">
        <!--Title-->
        <div class="common_product_item_title">
            <h3>Shop by Brands</h3>

        </div>
        <!--Product Category-->
        <div class="row">
            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!--Category item-->
                <div class="col-xl-2 col-lg-2 col-md-3 col-sm-6 p-4">
                    <img class="img-fluid mb-4" src="<?php echo e(asset('storage/Brand/' . $item->image)); ?>" alt="">
                    <div class="common_product_item_text">
                        <a style="font-size: 18px" href="<?php echo e(url('hardware/' . $item->title)); ?>">Shop
                            <?php echo e($item->title); ?></a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="d-flex justify-content-center mt-4">
            <form method="GET" action="<?php echo e(url('product/filter')); ?>"><button type="submit" class="common_button">
                    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <input type="hidden" name="filterbrand[]" value="<?php echo e($item->title); ?>">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    Shop all brands
                </button>
            </form>
        </div>
    </section>
    <!------Shop top brands.---->
    <br>

    <?php echo $__env->make('frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/ngenit/resources/views/frontend/product/shop_html.blade.php ENDPATH**/ ?>