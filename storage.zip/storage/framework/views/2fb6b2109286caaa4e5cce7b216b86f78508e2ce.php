<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!--=========Content Wrapper=============-->
    <?php echo $__env->make('frontend.client.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!--Content Wrapper-->
    <div class="d-flex">
        <div id="userSideButton_wrapper">
            <button class="sidebarButtonStyle" onclick="userDashboardSidebarClicked()">☰</button>
        </div>
        <div id="Content_Wrapper">
            <section class="client_dashboard_content_wp">
                <!--=====// Content body //=====-->
                <div id="client_dashboard_content_wp" class="row">
                    <?php echo $__env->make('frontend.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <!----Order Tracking start---->
                    <section class="row">
                        <!--------Serch & Title------->
                        <div class="col-lg-12 col-sm-12 d-flex justify-content-center">
                            <h2>Order Tracking</h2>
                        </div>
                        <div class="col-lg-12 col-sm-12 d-flex justify-content-center search_order_tracking">
                            <form id="form" role="search">
                                <input type="search" id="query" name="q" placeholder="Search..."
                                    aria-label="Search through site content">
                                <button type="submit">Search</button>
                            </form>
                        </div>
                        <!--------Managing item------->
                        <div class="col-lg-3 col-md-4 col-sm-6">
                            <div class="card-thumb">
                                <div class="card-img d-flex justify-content-center">
                                    <img src="<?php echo e(asset('assets/frontend/image/icon/managing-orders.png')); ?>" alt="">
                                </div>
                                <h4>Managing orders </h4>
                                <ul>
                                    <li><a href="">Order status</a></li>
                                    <li><a href="">Stock status</a></li>
                                    <li><a href="">Cancelling an order</a></li>
                                </ul>
                                <div class="d-flex justify-content-center order_tracking_btn mb-4">
                                    <a href="">Learn more</a>
                                </div>

                            </div>
                        </div>
                        <!--------Pricing item------->
                        <div class="col-lg-3 col-md-4 col-sm-6">
                            <div class="card-thumb">
                                <div class="card-img d-flex justify-content-center">
                                    <img src="<?php echo e(asset('assets/frontend/image/icon/pricing-payments.png')); ?>"
                                        alt="">
                                </div>
                                <h4>Pricing & payments</h4>
                                <ul>
                                    <li><a href="">Payment options</a></li>
                                    <li><a href="">Leasing options</a></li>
                                    <li><a href="">Find paid invoices</a></li>
                                </ul>
                                <div class="d-flex justify-content-center order_tracking_btn mb-4">
                                    <a href="">Learn more</a>
                                </div>

                            </div>
                        </div>
                        <!--------Shipping item------->
                        <div class="col-lg-3 col-md-4 col-sm-6">
                            <div class="card-thumb">
                                <div class="card-img d-flex justify-content-center">
                                    <img src="<?php echo e(asset('assets/frontend/image/icon/shipping-information.png')); ?>"
                                        alt="">
                                </div>
                                <h4>Shipping information</h4>
                                <ul>
                                    <li><a href="">Delivery options</a></li>
                                    <li><a href="">Shipping to different address</a></li>
                                    <li><a href="">Estimated delivery date</a></li>
                                </ul>
                                <div class="d-flex justify-content-center order_tracking_btn mb-4">
                                    <a href="">Learn more</a>
                                </div>

                            </div>
                        </div>
                        <!--------item------->
                        <div class="col-lg-3 col-md-4 col-sm-6">
                            <div class="card-thumb">
                                <div class="card-img d-flex justify-content-center">
                                    <img src="<?php echo e(asset('assets/frontend/image/icon/privacy-policies.png')); ?>"
                                        alt="">
                                </div>
                                <h4>Product Processing</h4>
                                <ul>
                                    <li><a href="">Order status</a></li>
                                    <li><a href="">Stock status</a></li>
                                    <li><a href="">Cancelling an order</a></li>
                                </ul>
                                <div class="d-flex justify-content-center order_tracking_btn mb-4">
                                    <a href="#">Learn more</a>
                                </div>

                            </div>
                        </div>
                    </section>
                    <!--Order Tracking End-->
                    <!--Order Details Start-->
                    <?php if($orders != null): ?>
                        <section class="client_db_oredr_details">
                            <div class="d-flex justify-content-center mb-4">
                                <h2>Order Details</h2>
                            </div>

                            <table class="table table-striped" style="font-size: 11px">
                                <thead class="thead-dark text-center">
                                    <tr>
                                        <th scope="col">#</th>
                                        <th scope="col">Product Name</th>
                                        <th scope="col">Quantity</th>
                                        <th scope="col">Unit Price</th>
                                        <th scope="col">Total Amount</th>
                                        <th scope="col">Delivery Status</th>
                                        <th scope="col">Payment Status</th>
                                        <th scope="col">Action</th>

                                    </tr>
                                </thead>
                                <tbody class="text-center">
                                    <?php
                                        $i = 1;
                                    ?>

                                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__currentLoopData = $items->orderDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($i++); ?></td>
                                                <td><?php echo e($item->product_name); ?></td>
                                                <td><?php echo e($item->quantity); ?></td>
                                                <td><?php echo e($item->unit_price); ?></td>
                                                <td><?php echo e($item->total_amount); ?></td>
                                                <td>
                                                    <?php if($item->delivery_status == 'Processing'): ?>
                                                        <a class="btn_action bg-primary"><?php echo e($item->delivery_status); ?></a>
                                                    <?php elseif($item->delivery_status == 'Shipped'): ?>
                                                        <a class="btn_action bg-secondary"><?php echo e($item->delivery_status); ?></a>
                                                    <?php elseif($item->delivery_status == 'Delivered'): ?>
                                                        <a class="btn_action btn-success"><?php echo e($item->delivery_status); ?></a>
                                                    <?php else: ?>
                                                        <a class="btn_action btn-warning"><?php echo e($item->delivery_status); ?></a>
                                                    <?php endif; ?>

                                                </td>
                                                <td>
                                                    <?php if($item->payment_status == 'Unpaid'): ?>
                                                        <a class="btn_action bg-danger"><?php echo e($item->payment_status); ?></a>
                                                    <?php elseif($item->payment_status == 'Checking'): ?>
                                                        <a class="btn_action bg-info"><?php echo e($item->payment_status); ?></a>
                                                    <?php elseif($item->payment_status == 'Paid'): ?>
                                                        <a class="btn_action bg-success"><?php echo e($item->payment_status); ?></a>
                                                    <?php else: ?>
                                                        <a class="btn_action bg-warning"><?php echo e($item->payment_status); ?></a>
                                                    <?php endif; ?>
                                                </td>
                                                <td>

                                                    <?php if($item->payment_status == 'Unpaid'): ?>
                                                        <a data-bs-toggle="modal" data-bs-target="#exampleModal"
                                                            style="cursor:pointer; color:rgba(241, 8, 43, 0.781)">
                                                            Payment Info
                                                        </a>
                                                    <?php else: ?>
                                                        <p>No Action Needed</p>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>

                                            <div class="modal fade" id="exampleModal" tabindex="-1"
                                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="exampleModalLabel">Payment Details
                                                            </h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                                aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <strong>Bank Name:</strong>
                                                            <p> Dutch Bangla Bank</p>
                                                            <strong>Account Title:</strong>
                                                            <p> NGen IT</p>
                                                            <strong>Account Number:</strong>
                                                            <p> 234***********</p>
                                                            <strong>Branch Title:</strong>
                                                            <p>West Panthapath</p>

                                                            <h5>Submit Payment Slip</h5>
                                                            <form action="<?php echo e(url('payment/update/' . $items->id)); ?>"
                                                                method="post" enctype="multipart/form-data"
                                                                class="form-group">
                                                                <?php echo csrf_field(); ?>
                                                                <input class="form-control" type="file"
                                                                    name="payment_slip" id="" required>
                                                                <button type="submit"
                                                                    style="border-radius: 50px; float:right"
                                                                    class="btn btn-sm btn-primary mt-2">Submit</button>
                                                            </form>

                                                        </div>
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </section>
                    <?php endif; ?>
                    <!--Order Details End-->
                </div>
            </section>
        </div>
    </div>
    </div>
    <?php echo $__env->make('frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/ngenit/resources/views/frontend/client/track.blade.php ENDPATH**/ ?>