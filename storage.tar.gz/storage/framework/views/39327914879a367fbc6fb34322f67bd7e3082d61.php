<?php $__env->startSection('content'); ?>



<div class="popup_modal">
    
    <div class="popup_modal_content" style="max-width: 570px; border: unset; background: linear-gradient(90deg, #af4286, #dd7fcd 100%, transparent 0);">
        <div class="popup_modal_content_wrapper">

            <!-- image -->
            <div class="neweLetter_image">
                <img src="assets/frontend/image/title-shape.png" alt="">
            </div>
            <!-- title -->
            <div class="neweLetter_title">
                <p> Our NewsLetter</p>
            </div>

            <!-- new form -->
            <div class="news_form_content">
                <div class="news_form_inner">
                    <input type="email" class=" form_newsletter" placeholder="Enter Your Email...">
                    <input type="button" value="Subscribe" class="newsLetter_btn">
                </div>

                <div class="news_form_text">
                    <p>We are going to send to mail </p>
                </div>
            </div>

            
            <!-- <div class="cross_btn">
                <span><i class="fa-solid fa-xmark"></i></span>
            </div> -->

        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/ngenit/resources/views/frontend/newsletter/newsletter.blade.php ENDPATH**/ ?>