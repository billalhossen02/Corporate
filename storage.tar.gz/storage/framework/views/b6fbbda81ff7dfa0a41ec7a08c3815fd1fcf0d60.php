<?php $__env->startSection('content'); ?>
    <!-- /# Sidebar -->
    <?php echo $__env->make('backend.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    <!-- /# Header -->
    <?php echo $__env->make('backend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    <?php echo $__env->make('frontend.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">

                

                <!-- /# row -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-title">
                                <h4>Edit Page For Brand <?php echo e($data->brand); ?> <span style="float: right;font-size:15px"><p><a href="<?php echo e(url('allpage')); ?>"><i class="fa fa-chevron-left" aria-hidden="true"></i>Back</a></p></span></h4>
                            </div>
                            <div class="card-body">
                                <div class="basic-form">
                                    <form class="row" action="<?php echo e(route('updatePage',['id' => $data->id])); ?>" method="POST"
                                        enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        


                                        <div class="col-12" style="border-bottom: 1px solid black">
                                            <div class="row">
                                                <div class="form-group col-lg-4 col-md-6 col-sm-12">
                                                    <label>Banner</label>
                                                    <img width="100px;" class="pull-right mb-2" src="<?php echo e(asset('storage/Banner/'.$data->banner)); ?>" alt="">
                                                    <input type="file" name="banner" class="form-control"
                                                        placeholder="Upload your banner">
                                                    <input type="hidden" name='previous_banner' value="<?php echo e($data->banner); ?>">
                                                </div>

                                                <div class="form-group col-lg-4 col-md-6 col-sm-12">
                                                    <label>H1</label>
                                                    <input type="text" name="h1" class="form-control"
                                                        value="<?php echo e($data->h1); ?>">
                                                </div>

                                                <div class="form-group col-lg-4 col-md-6 col-sm-12">
                                                    <label>H2</label>
                                                    <input type="text" name="h2" class="form-control"
                                                    value="<?php echo e($data->h2); ?>">
                                                </div>
                                            </div>
                                        </div>


                                        <div class="col-12" style="border-bottom: 1px solid black">
                                            <div class="row">
                                                <div class="form-group col-lg-4 col-md-6 col-sm-12">
                                                    <label>Circle 1 Image</label>
                                                    <img width="100px;" class="pull-right mb-2" src="<?php echo e(asset('storage/Circle1/'.$data->circle1)); ?>" alt="">
                                                    <input type="file" name="circle1" class="form-control"
                                                        placeholder="Upload your Circle 1 Image">
                                                    <input type="hidden" name="previous_circle1" value="<?php echo e($data->circle1); ?>">
                                                </div>

                                                <div class="form-group col-lg-4 col-md-6 col-sm-12">
                                                    <label>Circle 1 Text</label>
                                                    <input type="text" name="ctitle1" class="form-control"
                                                        value="<?php echo e($data->ctitle1); ?>">
                                                </div>



                                                <div class="form-group col-lg-4 col-md-6 col-sm-12">
                                                    <label>Circle 2 Image</label>
                                                    <img width="100px;" class="pull-right mb-2" src="<?php echo e(asset('storage/Circle2/'.$data->circle2)); ?>" alt="">
                                                    <input type="file" name="circle2" class="form-control"
                                                        placeholder="Upload your Circle 2 Image">
                                                        <input type="hidden" name="previous_circle2" value="<?php echo e($data->circle2); ?>">
                                                </div>

                                                <div class="form-group col-lg-4 col-md-6 col-sm-12">
                                                    <label>Circle 2 Text</label>
                                                    <input type="text" name="ctitle2" class="form-control"
                                                    value="<?php echo e($data->ctitle2); ?>">
                                                </div>



                                                <div class="form-group col-lg-4 col-md-6 col-sm-12">
                                                    <label>Circle 3 Image</label>
                                                    <img width="100px;" class="pull-right mb-2" src="<?php echo e(asset('storage/Circle2/'.$data->circle2)); ?>" alt="">
                                                    <input type="file" name="circle3" class="form-control">
                                                    <input type="hidden" name="previous_circle3" value="<?php echo e($data->circle3); ?>">
                                                </div>

                                                <div class="form-group col-lg-4 col-md-6 col-sm-12">
                                                    <label>Circle 3 Text</label>
                                                    <input type="text" name="ctitle3" class="form-control"
                                                    value="<?php echo e($data->ctitle3); ?>">
                                                </div>

                                            </div>
                                        </div>


                                        <div class="col-12" style="border-bottom: 1px solid black">
                                            <div class="row">

                                                <div class="form-group col-lg-4 col-md-6 col-sm-12">
                                                    <label>Title 1</label>
                                                    <input type="text" name="title1" class="form-control"
                                                       value="<?php echo e($data->title1); ?>">
                                                </div>

                                                <div class="form-group col-lg-4 col-md-6 col-sm-12">
                                                    <label>Description 1</label>
                                                    <input type="text" name="description1" class="form-control"
                                                        value="<?php echo e($data->description1); ?>">
                                                </div>

                                                <div class="form-group col-lg-4 col-md-6 col-sm-12">
                                                    <label>Button 1</label>
                                                    <input type="text" name="btn1" class="form-control"
                                                        value="<?php echo e($data->btn1); ?>">
                                                </div>

                                                <div class="form-group col-lg-4 col-md-6 col-sm-12">
                                                    <label> Image 1</label>
                                                    <img width="100px;" class="pull-right mb-2" src="<?php echo e(asset('storage/Img1/'.$data->img1)); ?>" alt="">
                                                    <input type="file" name="img1" class="form-control">
                                                    <input type="hidden" name="previous_img1" value="<?php echo e($data->img1); ?>">
                                                </div>


                                            </div>
                                        </div>

                                        <div class="col-12" style="border-bottom: 1px solid black">
                                            <div class="row">

                                                <div class="form-group col-lg-4 col-md-6 col-sm-12">
                                                    <label> Image 2</label>
                                                    <img width="100px;" class="pull-right mb-2" src="<?php echo e(asset('storage/Img2/'.$data->img2)); ?>" alt="">
                                                    <input type="file" name="img2" class="form-control"
                                                        placeholder="Upload your Image 2">
                                                        <input type="hidden" name="previous_img2" value="<?php echo e($data->img2); ?>">
                                                </div>

                                                <div class="form-group col-lg-4 col-md-6 col-sm-12">
                                                    <label>Title 2</label>
                                                    <input type="text" name="title2" class="form-control"
                                                    value="<?php echo e($data->title2); ?>">
                                                </div>

                                                <div class="form-group col-lg-4 col-md-6 col-sm-12">
                                                    <label>Description 2</label>
                                                    <input type="text" name="description2" class="form-control"
                                                        value="<?php echo e($data->description2); ?>">
                                                </div>

                                                <div class="form-group col-lg-4 col-md-6 col-sm-12">
                                                    <label>Button 2</label>
                                                    <input type="text" name="btn2" class="form-control"
                                                        value="<?php echo e($data->btn2); ?>">
                                                </div>



                                            </div>
                                        </div>

                                        <div class="col-12" style="border-bottom: 1px solid black">
                                            <div class="row">

                                                <div class="form-group col-lg-4 col-md-6 col-sm-12">
                                                    <label>Title 3</label>
                                                    <input type="text" name="title3" class="form-control"
                                                    value="<?php echo e($data->title3); ?>">
                                                </div>

                                                <div class="form-group col-lg-4 col-md-6 col-sm-12">
                                                    <label>Description 3</label>
                                                    <input type="text" name="description3" class="form-control"
                                                    value="<?php echo e($data->description3); ?>">
                                                </div>

                                                <div class="form-group col-lg-4 col-md-6 col-sm-12">
                                                    <label>Button 3</label>
                                                    <input type="text" name="btn3" class="form-control"
                                                    value="<?php echo e($data->btn3); ?>">
                                                </div>

                                                <div class="form-group col-lg-4 col-md-6 col-sm-12">
                                                    <label> Image 3</label>
                                                    <img width="100px;" class="pull-right mb-2" src="<?php echo e(asset('storage/Img3/'.$data->img3)); ?>" alt="">
                                                    <input type="file" name="img3" class="form-control"
                                                       >
                                                       <input type="hidden" name="previous_img3" value="<?php echo e($data->img3); ?>">

                                                </div>


                                            </div>
                                        </div>

                                        <div class="col-12" style="border-bottom: 1px solid black">
                                            <div class="row">

                                                <div class="form-group col-lg-4 col-md-6 col-sm-12">
                                                    <label> Image 4</label>
                                                    <img width="100px;" class="pull-right mb-2" src="<?php echo e(asset('storage/Img4/'.$data->img4)); ?>" alt="">
                                                    <input type="file" name="img4" class="form-control"
                                                        >
                                                        <input type="hidden" name="previous_img4" value="<?php echo e($data->img4); ?>">

                                                </div>

                                                <div class="form-group col-lg-4 col-md-6 col-sm-12">
                                                    <label>Title 4</label>
                                                    <input type="text" name="title4" class="form-control"
                                                    value="<?php echo e($data->title4); ?>">
                                                </div>

                                                <div class="form-group col-lg-4 col-md-6 col-sm-12">
                                                    <label>Description 4</label>
                                                    <input type="text" name="description4" class="form-control"
                                                    value="<?php echo e($data->description4); ?>">
                                                </div>

                                                <div class="form-group col-lg-4 col-md-6 col-sm-12">
                                                    <label>Button 4</label>
                                                    <input type="text" name="btn4" class="form-control"
                                                    value="<?php echo e($data->btn4); ?>">
                                                </div>

                                            </div>
                                        </div>

                                </div>
                                <button type="submit" class="btn btn-info ml-2 mt-2 pull-right">Update Page</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/ngenit/resources/views/backend/pagebuilder/edit.blade.php ENDPATH**/ ?>