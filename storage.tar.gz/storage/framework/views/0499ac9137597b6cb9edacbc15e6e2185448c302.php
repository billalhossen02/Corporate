<?php $__env->startSection('content'); ?>

<style>
    .form-group-inner{
        max-width: 380px;
        width: 100%
    }
</style>
      <!-- /# Sidebar -->
   <?php echo $__env->make('backend.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
   <!-- /# Header -->
   <?php echo $__env->make('backend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
   
    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
               
                    <!-- /# row -->
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-title">
                                    <h4>Select data for Client Widget</h4>
                                </div>

                                <div class="row">
                                <div class="card-body col-6">
                                    <div class="basic-form">
                                        <form class="" action="<?php echo e(route('addWidget')); ?>" method="POST" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <label>Story 1</label>
                                            <div class="form-group row"> 
                                             <div class="form-group-inner">
                                                <select name="title" class="form-control">
                                                    <option><?php echo e($data1[0]->title); ?></option>
                                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->title); ?>"><?php echo e($item->title); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="">
                                                <input type="hidden" value="1" name="id">
                                                <button type="submit" class="btn btn-info ml-2 mt-2">Update</button>
                                            </div>
                                               
                                            </div>
                                            </div>
                                            
                                        </form>
                                </div>

                                <div class="card-body col-6">
                                    <div class="basic-form">
                                        <form class="" action="<?php echo e(route('addWidget')); ?>" method="POST" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <label>Story 2</label>
                                            <div class="form-group row"> 
                                             <div class="form-group-inner">
                                                <select name="title" class="form-control">
                                                    <option><?php echo e($data1[1]->title); ?></option>
                                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->title); ?>"><?php echo e($item->title); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="">
                                                <input type="hidden" value="2" name="id">
                                                <button type="submit" class="btn btn-info ml-2 mt-2">Update</button>
                                            </div>
                                               
                                            </div>
                                            </div>
                                            
                                        </form>
                                </div>
                            </div>

                            <div class="row">
                                <div class="card-body col-6">
                                    <div class="basic-form">
                                        <form class="" action="<?php echo e(route('addWidget')); ?>" method="POST" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <label>Story 3</label>
                                            <div class="form-group row"> 
                                             <div class="form-group-inner">
                                                <select name="title" class="form-control">
                                                    <option><?php echo e($data1[2]->title); ?></option>
                                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->title); ?>"><?php echo e($item->title); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="">
                                                <input type="hidden" value="3" name="id">
                                                <button type="submit" class="btn btn-info ml-2 mt-2">Update</button>
                                            </div>
                                               
                                            </div>
                                            </div>
                                            
                                        </form>
                                </div>

                                <div class="card-body col-6">
                                    <div class="basic-form">
                                        <form class="" action="<?php echo e(route('addWidget')); ?>" method="POST" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <label>Story 4</label>
                                            <div class="form-group row"> 
                                             <div class="form-group-inner">
                                                <select name="title" class="form-control">
                                                    <option><?php echo e($data1[3]->title); ?></option>
                                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->title); ?>"><?php echo e($item->title); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="">
                                                <input type="hidden" value="4" name="id">
                                                <button type="submit" class="btn btn-info ml-2 mt-2">Update</button>
                                            </div>
                                               
                                            </div>
                                            </div>
                                            
                                        </form>
                                </div>
                            </div>

                            <div class="row">
                                <div class="card-body">
                                    <div class="basic-form">
                                        <form class="" action="<?php echo e(route('addWidget')); ?>" method="POST" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <label>Story 5</label>
                                            <div class="form-group row"> 
                                             <div class="form-group-inner">
                                                <select name="title" class="form-control">
                                                    <option><?php echo e($data1[4]->title); ?></option>
                                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($item->title); ?>"><?php echo e($item->title); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="">
                                                <input type="hidden" value="5" name="id">
                                                <button type="submit" class="btn btn-info ml-2 mt-2">Update</button>
                                            </div>
                                               
                                            </div>
                                            </div>
                                            
                                        </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    
            </div>
        </div>
    </div>

    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
                <!--/# row-->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-title">
                                <h4>All Client Experience </h4>
                                
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Name</th>
                                                <th>Image</th>
                                                <th>Description</th>
                                                
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php ($i=1); ?>
                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($i++); ?></td>
                                                <td><?php echo e($item->title); ?></td>
                                                <td><img src="<?php echo e(asset('storage/Client/'.$item->image)); ?>" width="40px" alt=""></td>
                                                <td><?php echo e($item->description); ?></td>
                                                
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                         
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
       </div>
       
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/ngenit/resources/views/backend/widget1/widget1_create.blade.php ENDPATH**/ ?>