<?php $__env->startSection('content'); ?>

      <!-- /# Sidebar -->
   <?php echo $__env->make('backend.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
   <!-- /# Header -->
   <?php echo $__env->make('backend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

   <div class="content-wrap">
    <div class="main">
        <div class="container-fluid">
            <!--/# row-->
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-title">
                            <h4>Catagory Page</h4>    
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table">
                                    <a href="<?php echo e(route('CategoriesT')); ?>"><button class="btn btn-sm btn-info pull-right">Create a Category</button></a>
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Category</th>
                                            <th>Sub Category</th>
                                            <th>Sub Sub Category</th>
                                            <th style="width:90px;">Image</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php ($i=1); ?>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($i++); ?></td>
                                            <td><?php echo e($item->category); ?></td>
                                            <td><?php echo e($item->sub_category); ?></td>
                                            <td><?php echo e($item->sub_sub_category); ?></td>
                                            <td><img src="<?php echo e(asset('storage/Category/'.$item->sub_img)); ?>" width="40px" alt=""></td>
                                            
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    </tbody>

                                </table>
                                <br>
                               <div class="pull-right"><?php echo e($categories->links()); ?></div> 

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
   
<?php $__env->stopSection(); ?>
    


<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/ngenit/resources/views/backend/category/category_view.blade.php ENDPATH**/ ?>