<?php $__env->startSection('content'); ?>
    <!-- /# Sidebar -->
    <?php echo $__env->make('backend.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    <!-- /# Header -->
    <?php echo $__env->make('backend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">

                <!-- /# row -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-title">
                                <h4>Create Your Template <span style="float: right;font-size:15px">
                                        <p><a href="<?php echo e(url('allpage')); ?>"><i class="fa fa-chevron-left"
                                                    aria-hidden="true"></i> view all page</a></p>
                                    </span></h4>
                            </div>
                            <div class="card-body">
                                <select name="select" id="select" onchange="myform(this)">
                                    <option value="">Select Your Template</option>
                                    <option value="home">Home Page</option>
                                    <option value="brand">Brand</option>
                                    <option value="category">Category</option>
                                </select>

                                <?php echo $__env->yieldContent('content'); ?>

                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <script>
            function myform(sel) {
                $var = sel.value;
                if ($var === 'brand') {
                    var url = "http://192.168.0.110/ngenit/public/pagebuilder/brand";
                    $(location).attr('href', url);
                }
                if ($var === 'category') {
                    var url = "http://192.168.0.110/ngenit/public/pagebuilder/category";
                    $(location).attr('href', url);
                }
                if ($var === 'home') {
                    var url = "http://192.168.0.110/ngenit/public/pagebuilder/home";
                    $(location).attr('href', url);
                }
            }
        </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/ngenit/resources/views/backend/pagebuilder/choose.blade.php ENDPATH**/ ?>