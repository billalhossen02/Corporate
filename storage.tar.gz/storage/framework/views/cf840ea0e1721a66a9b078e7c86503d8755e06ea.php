<?php $__env->startSection('content'); ?>
    <!-- header section -->
    <?php echo $__env->make('frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- header section End -->

    <!-- sign in page -->

    <div class="log_in_page">

        <!-- login form -->
        <div class="Login_form">
            <?php echo $__env->make('frontend.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="Login_form_content">
                <div class="Login_form_title">Create an account</div>

                <form method="POST" action="<?php echo e(route('register')); ?>">
                    <?php echo csrf_field(); ?>

                    <!-- inner -->
                    <div class="login_fomr_inner">
                        <label for="username">Name</label>
                        <input type="text" name="name" id="username" placeholder="Enter Your Name" required >
                    </div>

                    <!-- inner -->
                    <div class="login_fomr_inner">
                        <label for="username">Email</label>
                        <input type="email" name="email" id="username" placeholder="Enter Your Email" required >
                    </div>

                    <!-- inner -->
                    <div class="login_fomr_inner">
                        <label for="Password">Password</label>
                        <input type="password" name="password" minlength="8" id="Password" onChange="onChange()" placeholder="Enter Your Password" required>
                        <span class="login_show"><i class="bi bi-eye-slash" id="togglePassword"></i></span>

                    </div>

                    <!-- inner -->
                    <div class="login_fomr_inner">
                        <label for="Confirm">Confirm Password</label>
                        <input type="password" name="password_confirmation" minlength="8" id="Confirm"
                            onChange="onChange()" placeholder="Enter Confirm Password" required>
                            <span class="login_show"><i class="bi bi-eye-slash" id="toggleConfirm"></i></span>

                    </div>

                    <!-- submit buttton -->

                    <div class="submit_button">
                        <input type="submit" value="Create">
                    </div><br>
                   <div class="text-center"> Already a member? <a href="<?php echo e(route('login')); ?>" style="color: #ae0a46"> Login</a></div>
                </form>
            </div>
        </div>

    </div>
    <!-- sign in page End -->


    <?php echo $__env->make('frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/ngenit/resources/views/frontend/auth/register.blade.php ENDPATH**/ ?>