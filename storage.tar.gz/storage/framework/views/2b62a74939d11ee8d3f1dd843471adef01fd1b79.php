<?php $__env->startSection('content'); ?>

<!-- header section -->
<?php echo $__env->make('frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- header section End -->


<link rel="stylesheet" href="style.css">
<!-- banner single page start -->

<section class="banner_single_page">
    <div class="container">
        <div class="single_banner_content">
            <!-- image -->
            <div class="single_banner_image">
                <img src="" alt="">
            </div>
            <!-- heading -->
            <h1 class="single_banner_heading">Industries we serve</h1>
            <p class="single_banner_text">We combine deep industry experience and technology expertise to solve your IT
                challenges.</p>
            <!-- single banner button -->
            <div class="single_buttton_wrapper">
                <a href="#contact" class="single_banner_button">Talk to a specialist</a>
            </div>
        </div>
    </div>
</section>

<!-- banner single page end-->


<!-- industry solution -->
<section class="industry_solution section_padding">
    <div class="container">
        <!-- home title -->
        <div class="home_title" style="max-width: 1000px;">
            <h5 class="home_title_heading"> Solutions for your industry</h5>

            <p class="home_title_text">No two industries are the same. That’s why we tailor technology solutions to your
                business sector. Whether you need a robust security system to protect your data and ensure compliance or
                software that enhances your service delivery, we can help.</p>
        </div>

        <!-- wrapper -->

        <div class="industry_solution_wrapper">
            <!-- card item-->
            <div class="industry_solution_item">
                <div class="industry_solution_item_content">
                    <!-- img -->
                    <div class="industy_solution_item_image">
                        <img src="assets/frontend/image/industry/construction-industry-icon.png" alt="">
                    </div>
                    <!-- name -->
                    <div class="industy_solution_item_name">
                        <?php $__currentLoopData = $industries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $industry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><?php echo e($industry->title); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <div class="industy_solution_item_text">
                        <p>Adopt rugged and easy-to-manage solutions and services that help you increase productivity
                            and reduce construction costs.</p>
                    </div>
                </div>
                <a href="/blogs" class="industry_solution_item_button">Explore our solutions →</a>
            </div>
            <!-- item end -->

        </div>
    </div>
</section>
<!-- industry solution end -->

<!-- our clint tab -->



<!-- our clint tab end -->

<!-- we serve -->

<!-- we serve end -->

<!-- pageform section -->

<div id="contact" class="pageform_section section_padding">
    <div class="container">
        <!-- wrapper -->
        <div class="pageform_wrapper">
            <!-- content -->
            <div class="page_form_content">
                <div class="clint_help_section_heading_wrapper" style="flex-direction: column;">
                    <!-- title -->
                    <h5 class="home_title_heading" style="text-align: left; color: #fff;"> <span>Ind</span>ustries we
                        serve</h5>
                    <p class="home_title_text" style=" color: #fff; text-align: left; max-width: 885px;">We offer
                        breadth and depth —
                        combining deep industry expertise and technical skills to connect you to the right IT solutions.
                        With one strategic partner, you’ll get guidance at any stage of your IT transformation journey.
                    </p>
                </div>
            </div>
            <!-- pageform panel -->
            <div class="page_form_panel">
                <div class="right_contact_form_content">
                    <p class="right_form_title">Hear from our team</p>
                    <p class="right_form_subtitle">A specialist will reach out soon.</p>

                    <!-- wrapper -->
                    <div class="form_item_wrapper">

                        <!-- form item -->
                        <div class="form_item_inner">
                            <input class="form_input" type="text" placeholder="First Name">
                            <label class="form_label" for="">First Name: *</label>
                        </div>

                        <!-- form item -->
                        <div class="form_item_inner">
                            <input class="form_input" type="text" placeholder="Last Name">
                            <label class="form_label" for="">Last Name: *</label>
                        </div>

                        <!-- form item -->
                        <div class="form_item_inner">
                            <input class="form_input" type="number" placeholder="Phone">
                            <label class="form_label" for="">Phone: *</label>
                        </div>

                        <!-- form item -->
                        <div class="form_item_inner">
                            <input class="form_input" type="email" placeholder="Business Email">
                            <label class="form_label" for="">Business Email: *</label>
                        </div>

                        <!-- form item -->
                        <div class="form_item_inner">
                            <select name="" id="" class="form_input">
                                <option value="">Sate</option>
                                <option value="">Dhaka</option>
                                <option value="">Dinajpur</option>
                                <option value="">Rangpur</option>
                                <option value="">Panchagar</option>
                                <option value="">Nilphamari</option>
                                <option value="">Gajipur</option>
                                <option value="">Sylhet</option>
                            </select>
                        </div>

                        <!-- form item -->
                        <div class="form_item_inner">
                            <select name="" id="" class="form_input">
                                <option value="">Country</option>
                                <option value="">Bangladesh</option>
                                <option value="">India</option>
                                <option value="">Pakistan</option>
                                <option value="">Afganistan</option>
                            </select>
                            <!-- label -->
                            <label class="form_label" for="">Country: *</label>
                        </div>

                    </div>

                    <!-- form item -->
                    <div class="form_item_fullInner">
                        <input class="form_input" type="text" placeholder="Company/Organization">
                        <label class="form_label" for="">Company: *</label>
                    </div>

                    <!-- form item -->
                    <div class="form_item_fullInner">
                        <select name="" id="" class="form_input">
                            <option value="">Need help With...</option>
                            <option value="">Exploring solutions and services </option>
                            <option value="">Billing support </option>
                            <option value="">Order support </option>
                            <option value="">A general inquiry </option>
                        </select>
                    </div>

                    <!-- checkbox -->

                    <div class="form_checkbos_wrapper">
                        <!-- checkbox input -->
                        <div class="checkBox_inner">
                            <input type="checkbox">
                        </div>
                        <!-- content -->
                        <div class="checkBox_content">By checking this box, I consent to receive Insight marketing
                            emails. We respect your privacy and will not share your personal information with any other
                            company, person or identity.</div>
                    </div>

                    <!-- submit button -->
                    <a href="" class="single_banner_button" style="margin-top: 50px">Hear from a specialist</a>

                </div>
            </div>
        </div>
    </div>
</div>

<!-- feture content -->
<div class="feature_content section_padding">
    <div class="container">
        <!-- section title -->
        <div class="section_title">
            <h3 class="title_top_heading">Featured content</h3>
        </div>
        <!-- wrapper -->
        <div class="feature_content_wrapper">
            <!-- item -->
            <a href="" class="feature_content_item">
                <!-- image -->
                <div class="feature_content_item_thumbnail">
                    <img src="assets/frontend/image/single page/feature/feature1.jpg" alt="">
                </div>
                <!-- content -->
                <div class="feature_content_item_content">
                    <p class="feature_content_item_name"> Solution brief </p>
                    <p class="feature_content_item_text">Why Insight for Microsoft Cloud</p>
                </div>
            </a>

            <!-- item -->
            <a href="" class="feature_content_item">
                <!-- image -->
                <div class="feature_content_item_thumbnail">
                    <img src="assets/frontend/image/single page/feature/feature2.jpg" alt="">
                </div>
                <!-- content -->
                <div class="feature_content_item_content">
                    <p class="feature_content_item_name"> Solution brief </p>
                    <p class="feature_content_item_text">Why Insight for Microsoft Cloud</p>
                </div>
            </a>


            <!-- item -->
            <a href="" class="feature_content_item">
                <!-- image -->
                <div class="feature_content_item_thumbnail">
                    <img src="assets/frontend/image/single page/feature/feature3.jpg" alt="">
                </div>
                <!-- content -->
                <div class="feature_content_item_content">
                    <p class="feature_content_item_name"> Solution brief </p>
                    <p class="feature_content_item_text">Why Insight for Microsoft Cloud</p>
                </div>
            </a>


            <!-- item -->
            <a href="" class="feature_content_item">
                <!-- image -->
                <div class="feature_content_item_thumbnail">
                    <img src="assets/frontend/image/single page/feature/feature4.jpg" alt="">
                </div>
                <!-- content -->
                <div class="feature_content_item_content">
                    <p class="feature_content_item_name"> Solution brief </p>
                    <p class="feature_content_item_text">Why Insight for Microsoft Cloud</p>
                </div>
            </a>

        </div>
    </div>
</div>

<!-- feture content end-->

<!-- pageform section end-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/ngenit/resources/views/frontend/industry.blade.php ENDPATH**/ ?>