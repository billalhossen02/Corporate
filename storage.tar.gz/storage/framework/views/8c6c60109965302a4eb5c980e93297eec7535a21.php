<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- banner single page start -->
    <section class="banner_single_page">
        <div class="container">
            <div class="single_banner_content">
                <!-- image -->
                <div class="single_banner_image">
                    <img src="" alt="">
                </div>
                <!-- heading -->
                <h1 class="single_banner_heading"><?php echo e($data->h1); ?></h1>
                <p class="single_banner_text"><?php echo e($data->h2); ?></p>
                <div class="single_buttton_wrapper">
                    <form method="GET" action="<?php echo e(url('product/filter')); ?>"><button type="submit"
                            class="single_banner_button">
                            <input type="hidden" name="keyword" value="Cables">
                            Browse all cables</button>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <!-- network cable -->
    <section class="network_cable section_padding">
        <div class="container">

            <div class="section_title">
                <h3 class="title_top_heading">Display cables</h3>
            </div>

            <div class="network_cable_wrapper">
                <!-- item -->
                <div class="category_item_inner">
                    <!-- image -->
                    <div class="category_item_image">
                        <img src="<?php echo e(asset('storage/Category/' . $data->cat1[0]->sub_sub_sub_img)); ?>" alt="">
                    </div>
                    <!-- title -->
                    <div class="category_item_title"><?php echo e($data->cat1[0]->sub_sub_sub_category); ?></div>
                </div>
                <!-- item -->
                <div class="category_item_inner">
                    <!-- image -->
                    <div class="category_item_image">
                        <img src="<?php echo e(asset('storage/Category/' . $data->cat2[0]->sub_sub_sub_img)); ?>" alt="">
                    </div>
                    <!-- title -->
                    <div class="category_item_title"><?php echo e($data->cat2[0]->sub_sub_sub_category); ?></div>
                </div>
                <!-- item -->
                <div class="category_item_inner">
                    <!-- image -->
                    <div class="category_item_image">
                        <img src="<?php echo e(asset('storage/Category/' . $data->cat3[0]->sub_sub_sub_img)); ?>" alt="">
                    </div>
                    <!-- title -->
                    <div class="category_item_title"><?php echo e($data->cat3[0]->sub_sub_sub_category); ?></div>
                </div>
                <!-- item -->
                <div class="category_item_inner">
                    <!-- image -->
                    <div class="category_item_image">
                        <img src="<?php echo e(asset('storage/Category/' . $data->cat4[0]->sub_sub_sub_img)); ?>" alt="">
                    </div>
                    <!-- title -->
                    <div class="category_item_title"><?php echo e($data->cat4[0]->sub_sub_sub_category); ?></div>
                </div>

            </div>

            <div class="category_all_btn">
                <form method="GET" action="<?php echo e(url('product/filter')); ?>"><button type="submit" class="product_button">
                        <input type="hidden" name="keyword" value="Cables">
                        Shop all cables</button>
                </form>
            </div>

        </div>
    </section>

    <!-- network cable -->
    <section class="network_cable section_padding" style="background: #F7F6F5;">
        <div class="container">

            <div class="section_title">
                <h3 class="title_top_heading">Network cables</h3>
            </div>

            <div class="network_cable_wrapper">
                <!-- item -->
                <div class="category_item_inner">
                    <!-- image -->
                    <div class="category_item_image">
                        <img src="<?php echo e(asset('storage/Category/' . $data->cat5[0]->sub_sub_sub_img)); ?>" alt="">
                    </div>
                    <!-- title -->
                    <div class="category_item_title"><?php echo e($data->cat5[0]->sub_sub_sub_category); ?></div>
                </div>
                <!-- item -->
                <div class="category_item_inner">
                    <!-- image -->
                    <div class="category_item_image">
                        <img src="<?php echo e(asset('storage/Category/' . $data->cat6[0]->sub_sub_sub_img)); ?>" alt="">
                    </div>
                    <!-- title -->
                    <div class="category_item_title"><?php echo e($data->cat6[0]->sub_sub_sub_category); ?></div>
                </div>
                <!-- item -->
                <div class="category_item_inner">
                    <!-- image -->
                    <div class="category_item_image">
                        <img src="<?php echo e(asset('storage/Category/' . $data->cat7[0]->sub_sub_sub_img)); ?>" alt="">
                    </div>
                    <!-- title -->
                    <div class="category_item_title"><?php echo e($data->cat7[0]->sub_sub_sub_category); ?></div>
                </div>
                <!-- item -->
                <div class="category_item_inner">
                    <!-- image -->
                    <div class="category_item_image">
                        <img src="<?php echo e(asset('storage/Category/' . $data->cat8[0]->sub_sub_sub_img)); ?>" alt="">
                    </div>
                    <!-- title -->
                    <div class="category_item_title"><?php echo e($data->cat8[0]->sub_sub_sub_category); ?></div>
                </div>

            </div>

            <div class="category_all_btn">
                <form method="GET" action="<?php echo e(url('product/filter')); ?>"><button type="submit" class="product_button">
                        <input type="hidden" name="keyword" value="Cables">
                        Shop all cables</button>
                </form>
            </div>

        </div>
    </section>

    <!-- network cable -->
    <section class="network_cable section_padding">
        <div class="container">

            <div class="section_title">
                <h3 class="title_top_heading">Adapters</h3>
            </div>

            <div class="network_cable_wrapper">
                <!-- item -->
                <div class="category_item_inner">
                    <!-- image -->
                    <div class="category_item_image">
                        <img src="<?php echo e(asset('storage/Category/' . $data->cat9[0]->sub_sub_sub_img)); ?>" alt="">
                    </div>
                    <!-- title -->
                    <div class="category_item_title"><?php echo e($data->cat9[0]->sub_sub_sub_category); ?></div>
                </div>
                <!-- item -->
                <div class="category_item_inner">
                    <!-- image -->
                    <div class="category_item_image">
                        <img src="<?php echo e(asset('storage/Category/' . $data->cat10[0]->sub_sub_sub_img)); ?>" alt="">
                    </div>
                    <!-- title -->
                    <div class="category_item_title"><?php echo e($data->cat10[0]->sub_sub_sub_category); ?></div>
                </div>
                <!-- item -->
                <div class="category_item_inner">
                    <!-- image -->
                    <div class="category_item_image">
                        <img src="<?php echo e(asset('storage/Category/' . $data->cat11[0]->sub_sub_sub_img)); ?>" alt="">
                    </div>
                    <!-- title -->
                    <div class="category_item_title"><?php echo e($data->cat11[0]->sub_sub_sub_category); ?></div>
                </div>
                <!-- item -->
                <div class="category_item_inner">
                    <!-- image -->
                    <div class="category_item_image">
                        <img src="<?php echo e(asset('storage/Category/' . $data->cat12[0]->sub_sub_sub_img)); ?>" alt="">
                    </div>
                    <!-- title -->
                    <div class="category_item_title"><?php echo e($data->cat12[0]->sub_sub_sub_category); ?></div>
                </div>

            </div>

            <div class="category_all_btn">
                <form method="GET" action="<?php echo e(url('product/filter')); ?>"><button type="submit"
                        class="product_button">
                        <input type="hidden" name="keyword" value="Cables">
                        Shop all cables adapter</button>
                </form>
            </div>

        </div>
    </section>

    <section class="popular_product_section section_padding">
        <!-- container -->
        <div class="container">
            <div class="popular_product_section_content">
                <!-- section title -->
                <div class="section_title">
                    <h3 class="title_top_heading">Featured cables</h3>
                </div>
                <!-- wrapper -->
                <div class="populer_product_slider">

                    <!-- product_item -->

                    <div class="product_item">
                        <!-- image -->
                        <div class="product_item_thumbnail">
                            <img src="assets/frontend/image/single page/single product/product8.jpg" alt="">
                        </div>

                        <!-- product content -->
                        <div class="product_item_content">
                            <a href="" class="product_item_content_name">Microsoft Wireless Desktop 2000 - keyboard
                                and mouse set - QWERTY - US - black</a>

                            <!-- price -->
                            <div class="product_item_price">
                                <span class="price_currency">usd</span>
                                <span class="price_currency_value">$856</span>
                            </div>

                            <!-- button -->
                            <a href="" class="product_button">Add to Basket</a>
                        </div>

                    </div>
                    <!-- product item -->


                    <!-- product_item -->

                    <div class="product_item">
                        <!-- image -->
                        <div class="product_item_thumbnail">
                            <img src="assets/frontend/image/single page/single product/product8.jpg" alt="">
                        </div>

                        <!-- product content -->
                        <div class="product_item_content">
                            <a href="" class="product_item_content_name">Microsoft Wireless Desktop 2000 - keyboard
                                and mouse set - QWERTY - US - black</a>

                            <!-- price -->
                            <div class="product_item_price">
                                <span class="price_currency">usd</span>
                                <span class="price_currency_value">$856</span>
                            </div>

                            <!-- button -->
                            <a href="" class="product_button">Add to Basket</a>
                        </div>

                    </div>
                    <!-- product item -->


                    <!-- product_item -->

                    <div class="product_item">
                        <!-- image -->
                        <div class="product_item_thumbnail">
                            <img src="assets/frontend/image/single page/single product/product9.jpg" alt="">
                        </div>

                        <!-- product content -->
                        <div class="product_item_content">
                            <a href="" class="product_item_content_name">Microsoft Wireless Desktop 2000 - keyboard
                                and mouse set - QWERTY - US - black</a>

                            <!-- price -->
                            <div class="product_item_price">
                                <span class="price_currency">usd</span>
                                <span class="price_currency_value">$856</span>
                            </div>

                            <!-- button -->
                            <a href="" class="product_button">Add to Basket</a>
                        </div>

                    </div>
                    <!-- product item -->



                    <!-- product_item -->

                    <div class="product_item">
                        <!-- image -->
                        <div class="product_item_thumbnail">
                            <img src="assets/frontend/image/single page/single product/product10.jpg" alt="">
                        </div>

                        <!-- product content -->
                        <div class="product_item_content">
                            <a href="" class="product_item_content_name">Microsoft Wireless Desktop 2000 - keyboard
                                and mouse set - QWERTY - US - black</a>

                            <!-- price -->
                            <div class="product_item_price">
                                <span class="price_currency">usd</span>
                                <span class="price_currency_value">$856</span>
                            </div>

                            <!-- button -->
                            <a href="" class="product_button">Add to Basket</a>
                        </div>

                    </div>
                    <!-- product item -->


                    <!-- product_item -->

                    <div class="product_item">
                        <!-- image -->
                        <div class="product_item_thumbnail">
                            <img src="assets/frontend/image/single page/single product/product11.jpg" alt="">
                        </div>

                        <!-- product content -->
                        <div class="product_item_content">
                            <a href="" class="product_item_content_name">Microsoft Wireless Desktop 2000 - keyboard
                                and mouse set - QWERTY - US - black</a>

                            <!-- price -->
                            <div class="product_item_price">
                                <span class="price_currency">usd</span>
                                <span class="price_currency_value">$856</span>
                            </div>

                            <!-- button -->
                            <a href="" class="product_button">Add to Basket</a>
                        </div>

                    </div>
                    <!-- product item -->


                </div>
            </div>
        </div>
    </section>

    <!-- network cable -->
    <section class="network_cable section_padding" style="background: #F7F6F5;">
        <div class="container">

            <div class="section_title">
                <h3 class="title_top_heading">By brand</h3>
            </div>

            <div class="network_cable_wrapper2">

                <?php $__currentLoopData = $brands->take(20); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!-- item -->
                    <div class="category_item_inner">
                        <!-- image -->
                        <div class="category_item_image">
                            <img src="<?php echo e(asset('storage/Brand/' . $item->image)); ?>" alt="">
                        </div>
                        <!-- title -->
                        <div class="category_item_title">Shop <?php echo e($item->title); ?></div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

            <div class="category_all_btn">
                <a href="<?php echo e(url('partner.html')); ?>"><button class="product_button">Shop all Brand </button></a>
            </div>

        </div>
    </section>

    <!-- network cable -->
    <section class="network_cable section_padding">
        <div class="container">

            <div class="section_title">
                <h3 class="title_top_heading">Storage cables</h3>
            </div>

            <div class="network_cable_wrapper">
                <!-- item -->
                <div class="category_item_inner">
                    <!-- image -->
                    <div class="category_item_image">
                        <img src="<?php echo e(asset('storage/Category/' . $data->cat13[0]->sub_sub_sub_img)); ?>" alt="">
                    </div>
                    <!-- title -->
                    <div class="category_item_title"><?php echo e($data->cat13[0]->sub_sub_sub_category); ?></div>
                </div>
                <!-- item -->
                <div class="category_item_inner">
                    <!-- image -->
                    <div class="category_item_image">
                        <img src="<?php echo e(asset('storage/Category/' . $data->cat14[0]->sub_sub_sub_img)); ?>" alt="">
                    </div>
                    <!-- title -->
                    <div class="category_item_title"><?php echo e($data->cat14[0]->sub_sub_sub_category); ?></div>
                </div>
                <!-- item -->
                <div class="category_item_inner">
                    <!-- image -->
                    <div class="category_item_image">
                        <img src="<?php echo e(asset('storage/Category/' . $data->cat15[0]->sub_sub_sub_img)); ?>" alt="">
                    </div>
                    <!-- title -->
                    <div class="category_item_title"><?php echo e($data->cat15[0]->sub_sub_sub_category); ?></div>
                </div>
                <!-- item -->
                <div class="category_item_inner">
                    <!-- image -->
                    <div class="category_item_image">
                        <img src="<?php echo e(asset('storage/Category/' . $data->cat16[0]->sub_sub_sub_img)); ?>" alt="">
                    </div>
                    <!-- title -->
                    <div class="category_item_title"><?php echo e($data->cat16[0]->sub_sub_sub_category); ?></div>
                </div>

            </div>

            <div class="category_all_btn">
                <form method="GET" action="<?php echo e(url('product/filter')); ?>"><button type="submit"
                        class="product_button">
                        <input type="hidden" name="keyword" value="Cables">
                        Shop all cables</button>
                </form>
            </div>

        </div>
    </section>

    <!-- network cable -->
    <section class="network_cable section_padding" style="background: #F7F6F5;">
        <div class="container">

            <div class="section_title">
                <h3 class="title_top_heading">Power cables</h3>
            </div>

            <div class="network_cable_wrapper">
                <!-- item -->
                <div class="category_item_inner">
                    <!-- image -->
                    <div class="category_item_image">
                        <img src="<?php echo e(asset('storage/Category/' . $data->cat17[0]->sub_sub_sub_img)); ?>" alt="">
                    </div>
                    <!-- title -->
                    <div class="category_item_title"><?php echo e($data->cat17[0]->sub_sub_sub_category); ?></div>
                </div>
                <!-- item -->
                <div class="category_item_inner">
                    <!-- image -->
                    <div class="category_item_image">
                        <img src="<?php echo e(asset('storage/Category/' . $data->cat18[0]->sub_sub_sub_img)); ?>" alt="">
                    </div>
                    <!-- title -->
                    <div class="category_item_title"><?php echo e($data->cat18[0]->sub_sub_sub_category); ?></div>
                </div>
                <!-- item -->
                <div class="category_item_inner">
                    <!-- image -->
                    <div class="category_item_image">
                        <img src="<?php echo e(asset('storage/Category/' . $data->cat19[0]->sub_sub_sub_img)); ?>" alt="">
                    </div>
                    <!-- title -->
                    <div class="category_item_title"><?php echo e($data->cat19[0]->sub_sub_sub_category); ?></div>
                </div>
                <!-- item -->
                <div class="category_item_inner">
                    <!-- image -->
                    <div class="category_item_image">
                        <img src="<?php echo e(asset('storage/Category/' . $data->cat20[0]->sub_sub_sub_img)); ?>" alt="">
                    </div>
                    <!-- title -->
                    <div class="category_item_title"><?php echo e($data->cat20[0]->sub_sub_sub_category); ?></div>
                </div>

            </div>

            <div class="category_all_btn">
                <form method="GET" action="<?php echo e(url('product/filter')); ?>"><button type="submit"
                        class="product_button">
                        <input type="hidden" name="keyword" value="Cables">
                        Shop all cables</button>
                </form>
            </div>

        </div>
    </section>
    <?php echo $__env->make('frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/ngenit/resources/views/frontend/category/category.blade.php ENDPATH**/ ?>