<?php $__env->startSection('content'); ?>

    <!-- header section -->
    <?php echo $__env->make('frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- header section End -->


    <!-- Login page -->

    <div class="log_in_page">

        <!-- login form -->
        <div class="Login_form">
            <?php echo $__env->make('frontend.flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="Login_form_content">
                <div class="Login_form_title">Reset Password</div>
                <!-- inner -->
                <?php if(session('status')): ?>
                <div class="alert alert-success" role="alert">
                   <?php echo e(session('status')); ?>

                </div>
                    
                <?php endif; ?>
             <form method="POST" action="<?php echo e(route('password.request')); ?>">
                    <?php echo csrf_field(); ?>
                <div class="login_fomr_inner">
                    <label for="username">Email</label>
                    <input type="email" name="email" id="username" placeholder="Enter Your Email"> 
                </div>

                <!-- submit buttton -->

                <div class="submit_button">
                    <input type="submit" value="Log in">
                </div>
            </div>

            <!-- create account -->

            <a href="<?php echo e(route('register')); ?>" class="create_account">
                <span>New to NgenIt?</span>
                <span>Create an account</span>
            </a>
        </div>

    </form>

    </div>

    <!-- Login page End -->

    <?php echo $__env->make('frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/ngenit/resources/views/frontend/auth/forgot.blade.php ENDPATH**/ ?>