<div class="sidebar sidebar-hide-to-small sidebar-shrink sidebar-gestures">
    <div class="nano">
        <div class="nano-content">
            <ul>
                <div class="logo"><a href="<?php echo e(url('/admin')); ?>">
                        <img class="img-fluid" src="<?php echo e(asset('assets/backend/images/logo.png')); ?>" width="100px" alt=""/></a></div>
                <li class="label">Main</li>
                <li><a href="<?php echo e(url('/admin')); ?>" ><i class="ti-home"></i> Dashboard </a>
                </li>

                <li><a class="sidebar-sub-toggle"><i class="ti-bookmark-alt"></i> Role Management <span
                    class="sidebar-collapse-icon ti-angle-down"></span></a>
                    <ul>
                        <li><a href="<?php echo e(url('roles')); ?>">Manage Role</a></li>
                        <li><a href="<?php echo e(url('users')); ?>">Manage User</a></li>
                    </ul>
                </li>

                <li><a class="sidebar-sub-toggle"><i class="ti-layout"></i> Page Builder <span
                    class="sidebar-collapse-icon ti-angle-down"></span></a>
                    <ul>
                        
                        <li><a href="<?php echo e(url('allpage')); ?>">All Page</a></li>

                    </ul>
                </li>


                <li><a class="sidebar-sub-toggle"><i class="ti-blackboard"></i>Back Office<span
                    class="sidebar-collapse-icon ti-angle-down"></span></a>
                    <ul>
                        <li><a href="<?php echo e(route('order.details')); ?>">View</a></li>
                    </ul>
                </li>

                <li class="label">Apps</li>

                <li><a class="sidebar-sub-toggle"><i class="ti-shopping-cart-full"></i> Product & Category <span
                    class="sidebar-collapse-icon ti-angle-down"></span></a>
                    <ul>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product-list')): ?>
                        <li><a href="<?php echo e(route('products')); ?>">View all Product</a></li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product-create')): ?>
                        <li><a href="<?php echo e(route('ProductT')); ?>">Create a Product</a></li>
                        <?php endif; ?>
                        <li><a href="<?php echo e(route('categories')); ?>">View all Category</a></li>

                        <li><a href="<?php echo e(route('CategoriesT')); ?>">Create a Category</a></li>
                    </ul>
                </li>

                
                <li><a class="sidebar-sub-toggle"><i class="ti-book"></i> Blog & Brand <span
                    class="sidebar-collapse-icon ti-angle-down"></span></a>
                    <ul>
                        <li><a href="<?php echo e(route('blogs_backend')); ?>">View all Blog</a></li>
                        <li><a href="<?php echo e(route('blogs_create_backend')); ?>">Create a Blog</a></li>
                        <li><a href="<?php echo e(route('brands')); ?>">View all Brand</a></li>
                        <li><a href="<?php echo e(route('BrandsT')); ?>">Create a Brand</a></li> 
                        
                    </ul>
                </li>

                

                

                <li><a class="sidebar-sub-toggle"><i class="ti-briefcase"></i>Solution & Industry <span
                    class="sidebar-collapse-icon ti-angle-down"></span></a>
                    <ul>
                        <li><a href="<?php echo e(route('view_solution')); ?>">View all Solution</a></li>
                        <li><a href="<?php echo e(route('create_solution')); ?>">Create a Solution</a></li>
                        <li><a href="<?php echo e(route('industries')); ?>">View all Industry</a></li>
                        <li><a href="<?php echo e(route('IndustryT')); ?>">Create an Industry</a></li>
                    </ul>
                </li>

                <li><a class="sidebar-sub-toggle"><i class="ti-link"></i> Client Experience<span
                    class="sidebar-collapse-icon ti-angle-down"></span></a>
                    <ul>
                        <li><a href="<?php echo e(route('ClientT')); ?>">Create</a></li>
                    </ul>
                </li>

                <li><a class="sidebar-sub-toggle"><i class="ti-unlink"></i> Client Widget <span
                    class="sidebar-collapse-icon ti-angle-down"></span></a>
                    <ul>
                        
                        <li><a href="<?php echo e(route('widgetT')); ?>">Show</a></li>
                    </ul>
                </li>





                    <li><a class="sidebar-sub-toggle"><i class="ti-light-bulb"></i> Success <span
                    class="sidebar-collapse-icon ti-angle-down"></span></a>
                    <ul>
                        <li><a href="<?php echo e(route('view_success')); ?>">View</a></li>
                        
                    </ul>
                </li>
                
            </ul>
        </div>
    </div>
</div>
<?php /**PATH /var/www/html/ngenit/resources/views/backend/sidebar.blade.php ENDPATH**/ ?>