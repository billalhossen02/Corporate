<?php $__env->startSection('content'); ?>
    <!-- /# Sidebar -->
    <?php echo $__env->make('backend.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    <!-- /# Header -->
    <?php echo $__env->make('backend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

    <div class="content-wrap">
        <div class="main">
            <div class="container-fluid">
                <!--/# row-->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-title">
                                <h4>Order Details Page </h4>

                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>Order id</th>
                                                <th>Customer Name</th>
                                                <th>Shipping Address</th>

                                                <th>Product Name</th>
                                                <th>Quantity</th>
                                                <th>Total Price</th>
                                                <th>Payment Status</th>
                                                <th>Delivery Status</th>
                                                <th>Payment_Slip</th>

                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($item->id); ?></td>
                                                    <td><?php echo e($item->user_name); ?></td>
                                                    <td><?php echo e($item->address); ?>,<?php echo e($item->city); ?>,<?php echo e($item->country); ?>,<?php echo e($item->zip); ?>

                                                    </td>
                                                    <?php $__currentLoopData = $item->orderDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <td><?php echo e($item1->product_name); ?></td>
                                                        <td><?php echo e($item1->quantity); ?></td>
                                                        <td><?php echo e($item1->total_amount); ?></td>
                                                        <td>
                                                            <form method="post"
                                                                action="<?php echo e(url('order/update/' . $item1->id)); ?>">
                                                                <?php echo csrf_field(); ?>
                                                                <select name="payment_status"
                                                                    onchange='if(this.value != 0) { this.form.submit(); }'>
                                                                    <option value="<?php echo e($item1->payment_status); ?>">
                                                                        <?php echo e($item1->payment_status); ?></option>
                                                                    <?php $__currentLoopData = payment_status(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($pay); ?>">
                                                                            <?php echo e($pay); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </form>
                                                        </td>
                                                        <td>
                                                            <form method="post"
                                                                action="<?php echo e(url('order/update/' . $item1->id)); ?>">
                                                                <?php echo csrf_field(); ?>
                                                                <select name="delivery_status"
                                                                    onchange='if(this.value != 0) { this.form.submit(); }'>
                                                                    <option value="<?php echo e($item1->delivery_status); ?>">
                                                                        <?php echo e($item1->delivery_status); ?></option>
                                                                    <?php $__currentLoopData = delivery_status(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deliver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($deliver); ?>">
                                                                            <?php echo e($deliver); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </form>
                                                        </td>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($item->payment_slip != 0): ?>
                                                        <td><a href="<?php echo e(url('storage/Payment_Slip/' . $item->payment_slip)); ?>"
                                                                target="_blank"><i class="fa-solid fa-file"></i></a></td>
                                                    <?php else: ?>
                                                        <td>Unpaid</td>
                                                    <?php endif; ?>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>

                                    </table>
                                    <?php echo e($products->links()); ?>


                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/ngenit/resources/views/backend/order_details/view.blade.php ENDPATH**/ ?>