<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- banner single page start -->

    <section class="banner_single_page" style="background: url(<?php echo e(asset('storage/Banner/' . $solution->banner)); ?>)">
        <div class="container">
            <div class="single_banner_content">
                <!-- image -->
                <div class="single_banner_image">
                    <img width="200px" src="<?php echo e(asset('storage/Brand/' . $brand->image)); ?>" alt="">
                </div>
                <!-- heading -->
                <h1 class="single_banner_heading"><?php echo e($solution->h1); ?></h1>
                <p class="single_banner_text"><?php echo e($solution->h2); ?></p>
                <!-- single banner button -->
                <div class="single_buttton_wrapper">
                    <a href="<?php echo e(url('contact')); ?>" class="single_banner_button">Talk to a specialist</a>
                    <form method="GET" action="<?php echo e(url('product/filter')); ?>"><button type="submit"
                            href="<?php echo e(url('product/filter')); ?>" class="single_banner_button single_banner_button2"><input
                                type="hidden" name="keyword" value="<?php echo e($brand->title); ?>">
                            Shop all <?php echo e($brand->title); ?> devices</button></form>
                </div>
            </div>
        </div>
    </section>

    <!-- banner single page end-->



    <!-- single popular Product -->

    <section class="popular_product_section section_padding">
        <!-- container -->
        <div class="container">
            <div class="popular_product_section_content">
                <!-- section title -->
                <div class="section_title">
                    <h3 class="title_top_heading">Popular Products</h3>
                </div>
                <!-- wrapper -->
                <div class="populer_product_slider">

                    <!-- product_item -->
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="product_item">
                            <!-- image -->
                            <div class="product_item_thumbnail">
                                <img src="<?php echo e(asset('storage/Product/' . $item->image)); ?>" alt="">
                            </div>

                            <!-- product content -->
                            <div class="product_item_content">
                                <a href="<?php echo e(route('product', ['id' => $item->id])); ?>"
                                    class="product_item_content_name"><?php echo e($item->title); ?></a>

                                <!-- price -->
                                <div class="product_item_price">
                                    <span class="price_currency">usd</span>
                                    <span class="price_currency_value">$<?php echo e($item->price); ?></span>
                                </div>
                                <form class="myForm">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" value="<?php echo e($item->id); ?>"   name="id" id="id">
                                    <input type="hidden" value="<?php echo e($item->title); ?>" name="name" id="name">
                                    <input type="hidden" value="<?php echo e($item->price); ?>" name="price" id="price">
                                    <input type="hidden" value="<?php echo e($item->image); ?>" name="image" id="image">
                                    <input type="hidden" value="1" name="quantity" id="quantity">
                                    <button type="submit" class="product_button" data-toggle="modal" id="mediumButton"
                                        data-target="#mediumModal"
                                        data-attr="<?php echo e(route('modal', ['id' => $item->id])); ?>">Add to Basket</button>
                                </form>
                            </div>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!-- product item -->
                </div>
            </div>
        </div>
    </section>

    <!-- single popular Product end-->



    <!-- Product veiw details  -->

    <div class="product_veiw_details section_padding">
        <div class="container">
            <!-- section title -->
            <div class="section_title">
                <h3 class="title_top_heading">Surface is the answer.</h3>
                <p class="title_tex_content">You want a tablet, but you need a laptop. Microsoft Surface®, available from
                    Insight, offers the best of both.</p>
            </div>

            <!-- wrapper -->
            <div class="product_veiw_details_wrapper">

                <!-- item -->
                <div class="product_veiw_details_item">
                    <!-- image -->
                    <div class="product_veiw_details_item_image">
                        <img style="clip-path: circle();" src="<?php echo e(asset('storage/Circle1/' . $solution->circle1)); ?>"
                            alt="">
                    </div>
                    <!-- content -->
                    <div class="product_veiw_details_item_content">
                        <p style="font-size: 20px; margin: 4px 0px;">Versatile</p>
                        <p><?php echo e($solution->ctitle1); ?></p>
                    </div>
                </div>

                <!-- item -->
                <div class="product_veiw_details_item">
                    <!-- image -->
                    <div class="product_veiw_details_item_image">
                        <img style="clip-path: circle();" src="<?php echo e(asset('storage/Circle2/' . $solution->circle2)); ?>"
                            alt="">
                    </div>
                    <!-- content -->
                    <div class="product_veiw_details_item_content">
                        <p style="font-size: 20px; margin: 4px 0px;">Versatile</p>
                        <p><?php echo e($solution->ctitle2); ?></p>
                    </div>
                </div>

                <!-- item -->
                <div class="product_veiw_details_item">
                    <!-- image -->
                    <div class="product_veiw_details_item_image">
                        <img style="clip-path: circle();" src="<?php echo e(asset('storage/Circle3/' . $solution->circle3)); ?>"
                            alt="">
                    </div>
                    <!-- content -->
                    <div class="product_veiw_details_item_content">
                        <p style="font-size: 20px; margin: 4px 0px;">Versatile</p>
                        <p><?php echo e($solution->ctitle3); ?></p>
                    </div>
                </div>




            </div>
        </div>
    </div>

    <!-- Product veiw details end -->

    <!-- solution feature -->
  
        <section class="solution_feature">
            <div class="container">
                <div class="solution_feature_wrapper">
                    <?php $__currentLoopData = $solution->section1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <?php if($item->id != null): ?>
                        <!-- content -->
                        <div class="solution_feature_content">
                            
                            <div class="solution_feature_title"><?php echo e($item->title); ?></div>
        
                            <p class="solution_feature_text"><?php echo e($item->description); ?>

                            </p>
        
                        <a href="<?php echo e(url('single/product/'.$item->id)); ?>"><button class="product_button">Shop Now</button></a>
                        
        
                        
        
                        </div>
                        <!-- image -->
                        <div class="solution_feature_image">
                            <img src="<?php echo e(asset('storage/Product/'.$item->image)); ?>" alt="">
                        </div>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                   
                   

                </div>
            </div>
       
            <div class="container">
                <div class="solution_feature_wrapper">
                    <?php $__currentLoopData = $solution->sec1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <?php if($item->id != null): ?>
                        <!-- content -->
                        <div class="solution_feature_content">
                            
                            <div class="solution_feature_title"><?php echo e($item->title); ?></div>
        
                            <p class="solution_feature_text"><?php echo e($item->header1); ?>

                            </p>
        
                        <a href="<?php echo e(route('single',['id' =>$item->id])); ?>"><button class="product_button">Learn More</button></a>
                        
        
                        
        
                        </div>
                        <!-- image -->
                        <div class="solution_feature_image">
                            <img src="<?php echo e(asset('storage/Blog/'.$item->logo)); ?>" alt="">
                        </div>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                   
                   

                </div>
            </div>
        </section>
    

    <!-- Product solution end -->


    <!-- solution feature -->

    <section class="solution_feature solution_feature2">
        <div class="container">
            <div class="solution_feature_wrapper solution_feature_wrapper2">
                <?php $__currentLoopData = $solution->section2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <?php if($item->id != null): ?>
                    <!-- content -->
                    <div class="solution_feature_content">
                        
                        <div class="solution_feature_title"><?php echo e($item->title); ?></div>
    
                        <p class="solution_feature_text"><?php echo e($item->description); ?>

                        </p>
    
                    <a href="<?php echo e(url('single/product/'.$item->id)); ?>"><button class="product_button">Shop Now</button></a>
                    
    
                    
    
                    </div>
                    <!-- image -->
                    <div class="solution_feature_image">
                        <img src="<?php echo e(asset('storage/Product/'.$item->image)); ?>" alt="">
                    </div>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                   
               

            </div>
        </div>
   
        <div class="container">
            <div class="solution_feature_wrapper solution_feature_wrapper2">
                <?php $__currentLoopData = $solution->sec2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <?php if($item->id != null): ?>
                    <!-- content -->
                    <div class="solution_feature_content">
                        
                        <div class="solution_feature_title"><?php echo e($item->title); ?></div>
    
                        <p class="solution_feature_text"><?php echo e($item->header1); ?>

                        </p>
    
                    <a href="<?php echo e(route('single',['id' =>$item->id])); ?>"><button class="product_button">Learn More</button></a>
                    
    
                    
    
                    </div>
                    <!-- image -->
                    <div class="solution_feature_image">
                        <img src="<?php echo e(asset('storage/Blog/'.$item->logo)); ?>" alt="">
                    </div>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                   
               

            </div>
        </div>
    </section>

    <!-- solution feature end-->


    <!-- single popular Product -->

    <section class="popular_product_section section_padding">
        <!-- container -->
        <div class="container">
            <div class="popular_product_section_content">
                <!-- section title -->
                <div class="section_title">
                    <h3 class="title_top_heading">Top Products</h3>
                </div>
                <!-- wrapper -->
                <div class="populer_product_slider">

                    <!-- product_item -->
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="product_item">
                            <!-- image -->
                            <div class="product_item_thumbnail">
                                <img src="<?php echo e(asset('storage/Product/' . $item->image)); ?>" alt="">
                            </div>

                            <!-- product content -->
                            <div class="product_item_content">
                                <a href="<?php echo e(route('product', ['id' => $item->id])); ?>"
                                    class="product_item_content_name"><?php echo e($item->title); ?></a>

                                <!-- price -->
                                <div class="product_item_price">
                                    <span class="price_currency">usd</span>
                                    <span class="price_currency_value">$<?php echo e($item->price); ?></span>
                                </div>

                                <!-- button -->
                                <form class="myForm">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" value="<?php echo e($item->id); ?>"   name="id" id="id">
                                    <input type="hidden" value="<?php echo e($item->title); ?>" name="name" id="name">
                                    <input type="hidden" value="<?php echo e($item->price); ?>" name="price" id="price">
                                    <input type="hidden" value="<?php echo e($item->image); ?>" name="image" id="image">
                                    <input type="hidden" value="1" name="quantity" id="quantity">
                                    <button type="submit" class="product_button" data-toggle="modal" id="mediumButton"
                                        data-target="#mediumModal"
                                        data-attr="<?php echo e(route('modal', ['id' => $item->id])); ?>">Add to Basket</button>
                                </form>
                            </div>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!-- product item -->
                </div>
            </div>
        </div>
    </section>

    <!-- single popular Product end-->

    <!-- solution feature -->

    <section class="solution_feature">
        <div class="container">
            <div class="solution_feature_wrapper">
                <?php $__currentLoopData = $solution->section3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <?php if($item->id != null): ?>
                    <!-- content -->
                    <div class="solution_feature_content">
                        
                        <div class="solution_feature_title"><?php echo e($item->title); ?></div>
    
                        <p class="solution_feature_text"><?php echo e($item->description); ?>

                        </p>
    
                    <a href="<?php echo e(url('single/product/'.$item->id)); ?>"><button class="product_button">Shop Now</button></a>
                    
    
                    
    
                    </div>
                    <!-- image -->
                    <div class="solution_feature_image">
                        <img src="<?php echo e(asset('storage/Product/'.$item->image)); ?>" alt="">
                    </div>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                   
               

            </div>
        </div>
   
        <div class="container">
            <div class="solution_feature_wrapper">
                <?php $__currentLoopData = $solution->sec3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <?php if($item->id != null): ?>
                    <!-- content -->
                    <div class="solution_feature_content">
                        
                        <div class="solution_feature_title"><?php echo e($item->title); ?></div>
    
                        <p class="solution_feature_text"><?php echo e($item->header1); ?>

                        </p>
    
                    <a href="<?php echo e(route('single',['id' =>$item->id])); ?>"><button class="product_button">Learn More</button></a>
                    
    
                    
    
                    </div>
                    <!-- image -->
                    <div class="solution_feature_image">
                        <img src="<?php echo e(asset('storage/Blog/'.$item->logo)); ?>" alt="">
                    </div>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                   
               

            </div>
        </div>
    </section>

    <!-- Product solution end -->


    <!-- solution feature -->

    <section class="solution_feature solution_feature2">
        <div class="container">
            <div class="solution_feature_wrapper solution_feature_wrapper2">
                <?php $__currentLoopData = $solution->section4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <?php if($item->id != null): ?>
                    <!-- content -->
                    <div class="solution_feature_content">
                        
                        <div class="solution_feature_title"><?php echo e($item->title); ?></div>
    
                        <p class="solution_feature_text"><?php echo e($item->description); ?>

                        </p>
    
                    <a href="<?php echo e(url('single/product/'.$item->id)); ?>"><button class="product_button">Shop Now</button></a>
                    
    
                    
    
                    </div>
                    <!-- image -->
                    <div class="solution_feature_image">
                        <img src="<?php echo e(asset('storage/Product/'.$item->image)); ?>" alt="">
                    </div>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                   
               

            </div>
        </div>
   
        <div class="container">
            <div class="solution_feature_wrapper solution_feature_wrapper2">
                <?php $__currentLoopData = $solution->sec4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <?php if($item->id != null): ?>
                    <!-- content -->
                    <div class="solution_feature_content">
                        
                        <div class="solution_feature_title"><?php echo e($item->title); ?></div>
    
                        <p class="solution_feature_text"><?php echo e($item->header1); ?>

                        </p>
    
                    <a href="<?php echo e(route('single',['id' =>$item->id])); ?>"><button class="product_button">Learn More</button></a>
                    
    
                    
    
                    </div>
                    <!-- image -->
                    <div class="solution_feature_image">
                        <img src="<?php echo e(asset('storage/Blog/'.$item->logo)); ?>" alt="">
                    </div>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                   
               

            </div>
        </div>
    </section>

    <!-- solution feature end-->


    <!-- industry section -->

    

    <!-- industry section end -->


    <!-- feature content -->

    <div class="feature_content section_padding">
        <div class="container">
            <!-- section title -->
            <div class="section_title">
                <h3 class="title_top_heading">Featured content</h3>
            </div>
            <!-- wrapper -->
            <div class="feature_content_wrapper">
                <!-- item -->
                <a href="" class="feature_content_item">
                    <!-- image -->
                    <div class="feature_content_item_thumbnail">
                        <img src="<?php echo e(asset('assets/frontend/image/single page/feature/feature1.jpg')); ?>" alt="">
                    </div>
                    <!-- content -->
                    <div class="feature_content_item_content">
                        <p class="feature_content_item_name"> Solution brief </p>
                        <p class="feature_content_item_text">Why Insight for Microsoft Cloud</p>
                    </div>
                </a>

                <!-- item -->
                <a href="" class="feature_content_item">
                    <!-- image -->
                    <div class="feature_content_item_thumbnail">
                        <img src="<?php echo e(asset('assets/frontend/image/single page/feature/feature2.jpg')); ?>" alt="">
                    </div>
                    <!-- content -->
                    <div class="feature_content_item_content">
                        <p class="feature_content_item_name"> Solution brief </p>
                        <p class="feature_content_item_text">Why Insight for Microsoft Cloud</p>
                    </div>
                </a>


                <!-- item -->
                <a href="" class="feature_content_item">
                    <!-- image -->
                    <div class="feature_content_item_thumbnail">
                        <img src="<?php echo e(asset('assets/frontend/image/single page/feature/feature3.jpg')); ?>" alt="">
                    </div>
                    <!-- content -->
                    <div class="feature_content_item_content">
                        <p class="feature_content_item_name"> Solution brief </p>
                        <p class="feature_content_item_text">Why Insight for Microsoft Cloud</p>
                    </div>
                </a>


                <!-- item -->
                <a href="" class="feature_content_item">
                    <!-- image -->
                    <div class="feature_content_item_thumbnail">
                        <img src="<?php echo e(asset('assets/frontend/image/single page/feature/feature4.jpg')); ?>" alt="">
                    </div>
                    <!-- content -->
                    <div class="feature_content_item_content">
                        <p class="feature_content_item_name"> Solution brief </p>
                        <p class="feature_content_item_text">Why Insight for Microsoft Cloud</p>
                    </div>
                </a>

            </div>
        </div>
    </div>

    <!-- feature content end-->
    <?php echo $__env->make('frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>
    function my(){
       $var = $("#goja").val();
       if($var == 'Shop Now'){
        var url = "http://localhost/ngenit/public/single/product/8";
               $(location).attr('href',url);
       }

    }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/ngenit/resources/views/frontend/product/hardware.blade.php ENDPATH**/ ?>