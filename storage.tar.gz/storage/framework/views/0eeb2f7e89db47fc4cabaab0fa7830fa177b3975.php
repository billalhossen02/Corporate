<style>

.responsive {
  width: 100%;
  height: 100%;
}
</style>
<div>

    <img class="responsive" src="<?php echo e(asset('storage/error/4044.jpg')); ?>" alt="">
    
  </div><?php /**PATH /var/www/html/ngenit/resources/views/frontend/error/error.blade.php ENDPATH**/ ?>